# VX MD BOT — Telegram group pairing

## Pairing flow
- In the configured Telegram group, a member sends `/pair 919876543210` (country code included, digits only).
- The WhatsApp pairing code is posted in that same group with instructions and a copy button.
- The code message is removed after 60 seconds, or immediately when WhatsApp linking succeeds.
- On successful linking, the group receives a success message; the WhatsApp bot session continues to run and reconnect.
- If the code expires, the pairing lifecycle removes the unfinished session and reports expiration.
- Pairing is limited to `TELEGRAM_GROUP_ID`; configure the exact group chat ID in Railway Variables.

## Required Railway Variables
- `BOT_TOKEN`: Telegram bot token from BotFather (required).
- `TELEGRAM_GROUP_ID`: the configured group ID, commonly a negative number such as `-100...`.
- `TELEGRAM_GROUP_LINK`: group invite/link shown in helper messages.

## Important security note
The previous ZIP had a Telegram bot token embedded in `token.js`. That token has been removed from this ZIP. Revoke/rotate the previously exposed token in BotFather, then put the replacement only in Railway Variables. Never commit it to source code.

## Pairing engine fix (taken from VX_20MD_20BOT.zip, the build where linking works)
- `package.json`: Baileys was pinned to exactly `6.7.18`; now `^6.7.18` like the working build (Railway installs the newest 6.x, which keeps pairing compatible with current WhatsApp).
- `pair.js`: browser is `Browsers.macOS("Safari")` (same as working build); the pairing code is requested ~2.5s after the socket is created; after "Link device" (515) the restarted socket waits 2.5s and until `creds.json` is fully saved before logging in.
- `autoload.js`: the hourly auto-load never replaces the socket of a number that is being paired or is already online.
- Telegram side unchanged: group-only `/pair`, code posted with the DP image + copy button, removed after 60s or on success.


## Additional repair (2026-10-21)
- Pairing socket browser identity set to `Browsers.macOS("Safari")`, matching the known-good pairing flow.
- Baileys dependency allows compatible 6.x patch updates (`^6.7.18`).
- Removed the embedded Telegram bot token and default group ID from `token.js`; set these as Railway environment variables:
  - `BOT_TOKEN` (required; create/rotate it via BotFather)
  - `TELEGRAM_GROUP_ID` (required; run `/groupid` in the target group)
  - `TELEGRAM_GROUP_LINK` (group invite URL)
- If the old token was ever committed/shared, revoke it in BotFather and create a replacement before deployment.

## Menu / welcome media repair (2026-10-21)
- Kept the pairing flow and pairing-related files unchanged.
- If WhatsApp rejects the interactive menu with video header, `.menu` now falls back to a normal MP4 video with the menu caption instead of silently switching to an image.
- Menu media cache now keys local buffers by SHA-1 content, preventing different videos of the same size from sharing the wrong cached upload.
- Welcome URL download timeout reduced to 25 seconds and retry backoff reduced, so an unavailable URL does not hold the welcome event for as long; the loader can continue to the next configured video URL.
- If a welcome video URL fails, check `media/videos.json` and use a public direct MP4 URL (not a preview/webpage link). Enable in the group with `.welcome on` and `.welcome video on`.
