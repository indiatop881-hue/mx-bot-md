require('dotenv').config();
require('./setting/config');
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs').promises;
const fs2 = require("fs")
const path = require('path');
const chalk = require('chalk');
const { sleep } = require('./utils');
const { BOT_TOKEN, TELEGRAM_GROUP_ID, TELEGRAM_GROUP_LINK } = require('./token');

if (!BOT_TOKEN) {
  throw new Error('BOT_TOKEN is missing. Set it as an environment variable; do not put it in token.js.');
}

// Pairing requests are accepted only in the explicitly configured Telegram group.
const PAIR_GROUP_ID = String(process.env.TELEGRAM_GROUP_ID || TELEGRAM_GROUP_ID || '').trim();
const PAIR_GROUP_LINK = String(process.env.TELEGRAM_GROUP_LINK || TELEGRAM_GROUP_LINK || 'https://t.me/vzkbsiz').trim();
const isGroupChat = (chat) => chat && (chat.type === 'group' || chat.type === 'supergroup');
// An unset group ID disables pairing from groups instead of allowing every group.
const isPairGroup = (chat) => isGroupChat(chat) && !!PAIR_GROUP_ID && String(chat.id) === PAIR_GROUP_ID;
const { autoLoadPairs } = require('./autoload');
const axios = require("axios")

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const adminFilePath = path.join(__dirname, 'kingbadboitimewisher', 'admin.json');
let adminIDs = [];

// Store user states for pairing flow
const userStates = new Map();

const exists = async (filePath) => {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
};

const loadAdminIDs = async () => {
  const ownerID = '8141047238';
  const defaultAdmins = [ownerID];

  if (!(await exists(adminFilePath))) {
    await fs.writeFile(adminFilePath, JSON.stringify(defaultAdmins, null, 2));
    adminIDs = defaultAdmins;
    console.log('✅ Created admin.json with default owner ID');
  } else {
    try {
      const raw = await fs.readFile(adminFilePath, 'utf8');
      adminIDs = JSON.parse(raw);
    } catch (err) {
      console.error('Error loading admin.json:', err);
      adminIDs = defaultAdmins;
    }
  }
  console.log('📥 Loaded Admin IDs:', adminIDs);
};

let isShuttingDown = false;
let isAutoLoadRunning = false;

const runAutoLoad = async () => {
  if (isAutoLoadRunning || isShuttingDown) return;
  isAutoLoadRunning = true;

  try {
    console.log('⏱️ INITIATING AUTO-LOAD');
    await autoLoadPairs();
    console.log('✅ AUTO-LOAD COMPLETED');
  } catch (e) {
    console.error('❌ AUTO-LOAD FAILED:', e);
  } finally {
    isAutoLoadRunning = false;
  }
};

const startAutoLoadLoop = () => {
  runAutoLoad();
  setInterval(runAutoLoad, 60 * 60 * 1000);
};
startAutoLoadLoop();

const gracefulShutdown = (signal) => {
  if (isShuttingDown) return;
  isShuttingDown = true;
  
  console.log(`🛑 Received ${signal}. Shutting down gracefully...`);
  bot.stopPolling();
  console.log('✅ Bot stopped successfully');
  process.exit(0);
};

// ========== CHECK CHANNELS FUNCTION ==========
const checkUserJoinedChannels = async (userId) => {
  // Channel/group join verification disabled - everyone allowed
  return true;
};

// ========== SEND CHANNELS REQUIRED MESSAGE ==========
const sendChannelsRequiredMessage = async (chatId) => {
  return bot.sendMessage(chatId,
    `🚨 *You must join our official channels before pairing.*`,
    {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '📢 Channel 1', url: 'https://t.me/boygcaima' }],
          [{ text: '📢 Channel 2', url: 'https://t.me/wkkoqsvvdf' }],
          [{ text: '👥 Group', url: 'https://t.me/vzkbsiz' }],
          [{ text: '✅ I have joined', callback_data: 'check_join' }]
        ]
      }
    }
  );
};

// ========== SEND GROUP MESSAGE (STYLISH) ==========
const sendGroupMessage = async (chatId, replyToMessageId = null) => {
  const botInfo = await bot.getMe();
  const botUsername = botInfo.username;
  
  const message = `╭━━〔 🛡️ 𝙑𝙄𝙋 𝙎𝙀𝘾𝙐𝙍𝙀 〕━━╮
➤ Use in DM 👇
╰━━〔 🚀 𝙎𝙏𝘼𝙍𝙏 𝙉𝙊𝙒 〕━━╯`;

  const options = {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [{ text: '🚀 START NOW', url: `https://t.me/${botUsername}?start=pair` }]
      ]
    }
  };

  if (replyToMessageId) {
    options.reply_to_message_id = replyToMessageId;
  }

  return bot.sendMessage(chatId, message, options);
};

// ========== START COMMAND ==========
bot.onText(/^\/start(?:@\w+)?/, async (msg) => {
  const chatId = msg.chat.id;

  if (isGroupChat(msg.chat)) {
    return bot.sendMessage(chatId,
      `🪀 <b>The VX MD BOT💀</b>\n\nAny member can link WhatsApp here:\n<code>/pair 919876543210</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
  }

  // Private chat: no code here, send people to the pairing group
  await bot.sendPhoto(
    chatId,
    "https://files.catbox.moe/l2gb41.jpg",
    {
      caption: `🪀 *𝙏𝙝𝙚 𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧💀*\n\n🔒 Pairing code is given only in our official group.\n👇 Join the group and send:\n/pair <wa_number>`,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '👥 Join Group', url: PAIR_GROUP_LINK }],
          [{ text: "👑 Owner", url: "https://t.me/MON_STAR_001" }]
        ]
      }
    }
  ).catch(() => {});
});

// Helper: send /groupid in any group to learn its ID (paste it into token.js -> TELEGRAM_GROUP_ID)
bot.onText(/^\/groupid(?:@\w+)?/, async (msg) => {
  return bot.sendMessage(msg.chat.id, `🆔 Chat ID: <code>${msg.chat.id}</code>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id }).catch(() => {});
});

// ========== PAIRING CORE (code is posted in the configured pairing group) ==========
const DP_CODE_IMG = path.join(__dirname, 'media', 'image1.jpg');   // DP sent with EVERY pairing code
const DP_OK_IMG = path.join(__dirname, 'media', 'scar1.jpg');      // different DP sent on successful link
const pairCooldown = new Map();
const PAIR_COOLDOWN_MS = 8000;

const escHtml = (t) => String(t || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const readImg = (file) => {
  try { return fs2.readFileSync(file); } catch { return null; }
};
const photoOpts = { filename: 'dp.jpg', contentType: 'image/jpeg' };

const sendPhotoOrText = async (chatId, file, text, options) => {
  const img = readImg(file);
  if (img) {
    try {
      return await bot.sendPhoto(chatId, img, { caption: text, ...options }, photoOpts);
    } catch (e) {
      console.error('sendPhoto failed, falling back to text:', e.message);
    }
  }
  return bot.sendMessage(chatId, text, options);
};

// DM / wrong group: no code, just tell the user to join the pairing group
const sendJoinGroupMessage = (chatId, replyTo) => bot.sendMessage(chatId,
  `🔒 <b>Pairing code is given only in our official group.</b>\n\n` +
  `1. Join the group with the button below\n` +
  `2. In the group send: <code>/pair 919876543210</code>\n\n` +
  `The code will be posted in this group and removed when it expires or links successfully.`,
  {
    parse_mode: 'HTML',
    ...(replyTo ? { reply_to_message_id: replyTo } : {}),
    reply_markup: { inline_keyboard: [[{ text: '👥 Join Group', url: PAIR_GROUP_LINK }]] }
  }
).catch(() => null);

// ONE message format for every code (first request, 2nd request, refresh) - always DP + code + copy button
const sendCodeMessage = async (chatId, replyTo, number, code, jid) => {
  const caption =
    `🔗 <b>Pairing Code for WhatsApp</b>\n\n` +
    `📱 <b>Number:</b> +${number}\n` +
    `🔑 <b>Code:</b> <code>${escHtml(code)}</code>\n\n` +
    `➡️ <b>Instructions</b>\n` +
    `1. Open WhatsApp → Settings → Linked Devices\n` +
    `2. Tap <b>Link a Device</b> → <b>Link with phone number instead</b>\n` +
    `3. Enter the code above\n\n` +
    `⚠️ <i>Code expires in 60 seconds. If it expires, request a fresh code.</i>`;
  const base = { parse_mode: 'HTML', ...(replyTo ? { reply_to_message_id: replyTo } : {}) };
  const markup = (copyText) => ({
    inline_keyboard: [[
      copyText
        ? { text: '📋 Copy Code', copy_text: { text: code } }
        : { text: '📋 Copy Code', callback_data: `copy_code_${code}` }
    ]]
  });
  let sent;
  try {
    sent = await sendPhotoOrText(chatId, DP_CODE_IMG, caption, { ...base, reply_markup: markup(true) });
  } catch (e) {
    console.error('copy_text button failed, using callback button:', e.message);
    sent = await sendPhotoOrText(chatId, DP_CODE_IMG, caption, { ...base, reply_markup: markup(false) });
  }
  try {
    const pend = global.pairPending && global.pairPending.get(jid);
    if (pend && sent && sent.message_id) {
      // Keep the code in the Telegram pairing group for at most 60 seconds.
      // Successful linking clears this timer and removes the code immediately.
      if (pend.codeMessageTimer) clearTimeout(pend.codeMessageTimer);
      pend.codeMsgId = sent.message_id;
      pend.codeMessageTimer = setTimeout(() => {
        bot.deleteMessage(pend.chatId, pend.codeMsgId).catch(() => {});
        pend.codeMsgId = null;
      }, 60000);
      if (typeof pend.codeMessageTimer.unref === 'function') pend.codeMessageTimer.unref();
    }
  } catch (e) { /* ignore */ }
  return sent;
};

const credsAccount = (jid) => {
  try {
    const credsPath = path.join(__dirname, 'kingbadboitimewisher', 'pairing', jid, 'creds.json');
    if (!fs2.existsSync(credsPath)) return false;
    const creds = JSON.parse(fs2.readFileSync(credsPath, 'utf8'));
    return !!(creds && creds.account);
  } catch { return false; }
};

const processPair = async (msg, number) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const replyTo = msg.message_id;
  const base = { parse_mode: 'HTML', reply_to_message_id: replyTo };

  // Code only inside the pairing group. DM / any other chat -> "join the group"
  if (!isPairGroup(msg.chat)) {
    return sendJoinGroupMessage(chatId, replyTo);
  }

  if (/[a-z]/i.test(number)) {
    return bot.sendMessage(chatId, '❌ <b>Letters are not allowed.</b>\n\nSend only numbers. Example: <code>/pair 919876543210</code>', base);
  }
  if (!/^\d{7,15}$/.test(number)) {
    return bot.sendMessage(chatId, '❌ <b>Invalid number.</b>\n\nExample: <code>/pair 919876543210</code> (country code, no + or spaces)', base);
  }
  if (number.startsWith('0')) {
    return bot.sendMessage(chatId, '❌ <b>Numbers starting with 0 are not allowed.</b>\n\nPlease include the country code.', base);
  }
  if (["252", "201"].includes(number.slice(0, 3))) {
    return bot.sendMessage(chatId, '❌ <b>Numbers with this country code are not supported.</b>', base);
  }

  const last = pairCooldown.get(userId) || 0;
  if (Date.now() - last < PAIR_COOLDOWN_MS) {
    return bot.sendMessage(chatId, '⏳ Please wait a few seconds before requesting another code.', base);
  }
  pairCooldown.set(userId, Date.now());

  const pairingFolder = path.join(__dirname, 'kingbadboitimewisher', 'pairing');
  if (!(await exists(pairingFolder))) await fs.mkdir(pairingFolder, { recursive: true });
  const files = await fs.readdir(pairingFolder);
  if (files.filter(f => f.endsWith('@s.whatsapp.net')).length >= 1000) {
    return bot.sendMessage(chatId, '❌ <b>Pairing limit reached.</b>\n\nPlease try again later.', base);
  }

  const jid = number + '@s.whatsapp.net';
  const startpairing = require('./pair.js'); // also registers the global pairing helpers

  // After a logout from the phone the old socket needs a few seconds to notice it (401). Give it up to 8s
  // before saying "already online", so logout -> /pair works again and again.
  for (let i = 0; i < 16 && global.isPairNumberOnline && global.isPairNumberOnline(jid); i++) await sleep(500);
  if (global.isPairNumberOnline && global.isPairNumberOnline(jid)) {
    return bot.sendMessage(chatId, `ℹ️ <b>+${number}</b> is still linked and online.\nFirst log out this bot from WhatsApp → Linked Devices, wait a few seconds, then send <code>/pair ${number}</code> again.`, base);
  }

  // Do not let a second Telegram member replace an active code. Replacing the
  // socket invalidates the first code and is the main cause of "Couldn't link
  // device" after the same number is requested twice.
  const activePend = global.pairPending && global.pairPending.get(jid);
  if (activePend && Date.now() - activePend.ts < 60000) {
    return bot.sendMessage(chatId,
      `⏳ <b>Pairing for +${number} is already in progress.</b>\n\nWait for the current code to finish or expire in 60 seconds before requesting another one.`,
      base);
  }

  // A saved linked session is never deleted just because its socket is reconnecting. But if the number was
  // logged out from the phone, that saved session is dead (WhatsApp answers 401) and re-using it is what
  // broke the 2nd pairing. So: reconnect it and WATCH. Online -> really connected. 401 -> pair.js wipes the
  // dead session and this same /pair request continues with a brand-new pairing code (no second command).
  let quickReset = false;
  if (credsAccount(jid)) {
    let probe = 'unknown';
    if (typeof global.fastProbeSession === 'function') {
      probe = await global.fastProbeSession(jid, 15000);
    } else {
      try { await startpairing(jid); } catch (e) { console.error(`Existing session reconnect failed for ${jid}:`, e.message); }
      for (let i = 0; i < 90; i++) {
        await sleep(500);
        if (global.isPairNumberOnline && global.isPairNumberOnline(jid)) { probe = 'online'; break; }
        if (!credsAccount(jid)) { probe = 'wiped'; break; }
      }
    }
    if (probe === 'online') {
      pairCooldown.delete(userId);
      return bot.sendMessage(chatId,
        `ℹ️ <b>+${number}</b> is already linked and online.\n\nTo pair again, first log out this bot from WhatsApp → Linked Devices, then send <code>/pair ${number}</code>.`,
        base);
    }
    if (probe !== 'wiped') {
      pairCooldown.delete(userId);
      return bot.sendMessage(chatId,
        `ℹ️ <b>+${number}</b> has a saved session and is still reconnecting.\n\nWait about 20 seconds and send <code>/pair ${number}</code> again. If it was logged out from WhatsApp, a fresh code will be given.`,
        base);
    }
    quickReset = true;
    console.log(`[pair] ${jid}: saved session was logged out, continuing with a fresh pairing code`);
  }

  // Only an unfinished pairing session is cleaned below.

  // Every new request starts from ZERO: old socket, old session files, old code, old pending state are wiped.
  // (leftovers of the previous link / logout were what made the 2nd pairing fail)
  const oldPend = global.pairPending && global.pairPending.get(jid);
  if (oldPend && oldPend.codeMsgId) bot.deleteMessage(oldPend.chatId, oldPend.codeMsgId).catch(() => {});
  if (global.pairPending) global.pairPending.delete(jid);
  if (global.resetPairSession) await global.resetPairSession(jid, quickReset);
  else { try { await fs.rm(path.join(pairingFolder, jid), { recursive: true, force: true }); } catch (e) {} }
  // stale code file of an earlier number must never be shown (same as the working build)
  try { await fs.unlink(path.join(pairingFolder, 'pairing.json')); } catch (e) {}

  userStates.delete(userId);
  const wait = await bot.sendMessage(chatId, '⏳ <b>Generating pairing code...</b>\n\nPlease wait a moment.', base).catch(() => null);

  try {
    global.pairingCodes = global.pairingCodes || {};
    global.pairPending = global.pairPending || new Map();
    global.pairingErrors = global.pairingErrors || {};
    delete global.pairingCodes[jid];
    delete global.pairingErrors[jid];
    global.pairPending.set(jid, {
      source: 'telegram',
      ts: Date.now(),
      // User explicitly requested the pairing code and status in the configured group.
      chatId: chatId,
      userId,
      replyTo,
      name: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || msg.from.username || 'User',
      username: msg.from.username || null
    });

    await startpairing(jid);

    let code = null;
    for (let i = 0; i < 360 && !code; i++) {   // 360 x 250ms = 90s, but the code shows up the moment it exists
      await sleep(250);
      code = global.pairingCodes[jid] && global.pairingCodes[jid].code;
    }

    if (wait) bot.deleteMessage(chatId, wait.message_id).catch(() => {});

    if (!code) {
      const why = global.pairingErrors && global.pairingErrors[jid];
      global.pairPending.delete(jid);
      if (global.resetPairSession) await global.resetPairSession(jid); // leave nothing behind for the next try
      pairCooldown.delete(userId);
      return bot.sendMessage(chatId, '❌ <b>Could not generate a code.</b>\n\nPlease check the number and send /pair again in a minute.' + (why ? `\n\n<i>Reason: ${escHtml(String(why).slice(0, 120))}</i>` : ''), base);
    }

    try {
      return await sendCodeMessage(chatId, replyTo, number, code, jid);
    } catch (dmError) {
      console.error('PAIR PRIVATE MESSAGE ERROR:', dmError.message);
      if (global.pairPending) global.pairPending.delete(jid);
      if (global.resetPairSession) await global.resetPairSession(jid);
      pairCooldown.delete(userId);
      return bot.sendMessage(chatId,
        '❌ Could not post the pairing code in this group. Check that the bot can send messages and photos here, then try /pair again.',
        base);
    }
  } catch (error) {
    console.error('PAIR COMMAND ERROR:', error);
    if (wait) bot.deleteMessage(chatId, wait.message_id).catch(() => {});
    if (global.pairPending) global.pairPending.delete(jid);
    if (global.resetPairSession) await global.resetPairSession(jid);
    pairCooldown.delete(userId);
    return bot.sendMessage(chatId, '❌ <b>Pairing service is temporarily unavailable.</b>\n\nPlease try again later.', base);
  }
};

// Called from pair.js if a NEW code had to replace the one already shown -> same format (DP + code), old message removed
global.onPairCodeRefresh = async (jid, code) => {
  const pend = global.pairPending && global.pairPending.get(jid);
  if (!pend || pend.source !== 'telegram') return;
  if (pend.codeMessageTimer) { clearTimeout(pend.codeMessageTimer); pend.codeMessageTimer = null; }
  if (pend.codeMsgId) { await bot.deleteMessage(pend.chatId, pend.codeMsgId).catch(() => {}); pend.codeMsgId = null; }
  await sendCodeMessage(pend.chatId, pend.replyTo, jid.split('@')[0], code, jid).catch(() => null);
};

// Called from pair.js when nobody linked within the code lifetime
global.onPairExpired = async (jid, pend) => {
  if (!pend || pend.source !== 'telegram') return;
  if (pend.codeMessageTimer) { clearTimeout(pend.codeMessageTimer); pend.codeMessageTimer = null; }
  if (pend.codeMsgId) { await bot.deleteMessage(pend.chatId, pend.codeMsgId).catch(() => {}); pend.codeMsgId = null; }
  pairCooldown.delete(pend.userId);
  await bot.sendMessage(pend.chatId,
    `⌛ <b>Pairing code for +${jid.split('@')[0]} expired.</b>\n\nSend <code>/pair ${jid.split('@')[0]}</code> again to get a fresh code.`,
    { parse_mode: 'HTML', reply_to_message_id: pend.replyTo }).catch(() => {});
};

// Called from pair.js when the WhatsApp device is really linked
global.onPairSuccess = async (jid, pend) => {
  if (!pend || pend.source !== 'telegram') return;
  const number = jid.split('@')[0];
  // pairing code message is removed, only the success message stays
  if (pend.codeMessageTimer) { clearTimeout(pend.codeMessageTimer); pend.codeMessageTimer = null; }
  if (pend.codeMsgId) { await bot.deleteMessage(pend.chatId, pend.codeMsgId).catch(() => {}); pend.codeMsgId = null; }
  pairCooldown.delete(pend.userId);
  const who = pend.username ? `@${escHtml(pend.username)}` : `<b>${escHtml(pend.name)}</b>`;
  const caption =
    `✅ <b>WhatsApp Linked Successfully!</b>\n\n` +
    `📱 <b>Number:</b> +${number}\n` +
    `👤 <b>Linked by:</b> ${who}\n\n` +
    `🤖 Your bot is now <b>online</b>. Open your WhatsApp personal chat — a welcome message is waiting there.\n` +
    `Type <code>.menu</code> to start.`;
  await sendPhotoOrText(pend.chatId, DP_OK_IMG, caption, {
    parse_mode: 'HTML',
    reply_to_message_id: pend.replyTo,
    reply_markup: { inline_keyboard: [[{ text: '👑 Owner', url: 'https://t.me/MON_STAR_001' }]] }
  });
};

// ========== PAIR COMMAND ==========
bot.onText(/^\/pair(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;

  // DM or any other group: no code, only "join the group"
  if (!isPairGroup(msg.chat)) return sendJoinGroupMessage(chatId, msg.message_id);

  const text = match[1]?.trim().replace(/[\s+\-()]/g, '');
  if (!text) {
    return bot.sendMessage(chatId,
      `🔐 <b>Send your WhatsApp number with country code</b>\n\nExample: <code>/pair 917018062209</code>`,
      { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
    );
  }

  return processPair(msg, text);
});

// ========== CALLBACK QUERY HANDLER ==========
bot.on('callback_query', async (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id;
  const chatId = msg.chat.id;

  if (data && data.startsWith('copy_code_')) {
    const code = data.replace('copy_code_', '');
    await bot.answerCallbackQuery(callbackQuery.id, { 
      text: `✅ Code copied: ${code}`, 
      show_alert: true
    });
    return;
  }

  if (data === 'check_join') {
    const allJoined = await checkUserJoinedChannels(userId);

    if (allJoined) {
      await bot.answerCallbackQuery(callbackQuery.id, { 
        text: '✅ Thanks for joining! Now use /pair command.', 
        show_alert: true
      });
      await bot.sendMessage(chatId, '✅ *Thanks for joining all channels!*\n\nNow send /pair to start pairing.', { parse_mode: 'Markdown' });
    } else {
      await bot.answerCallbackQuery(callbackQuery.id, { 
        text: '❌ Please join all channels first!', 
        show_alert: true
      });
    }
    return;
  }
});

// ========== PRIVATE CHAT HANDLER: someone writes "pairing" / "pair" / a number in DM -> send them to the group ==========
bot.on('message', async (msg) => {
  if (!msg.chat || msg.chat.type !== 'private') return;
  const text = (msg.text || '').trim();
  if (!text) return;
  if (/^\/(start|pair|groupid)\b/i.test(text)) return; // handled by their own commands
  if (/^\/?(pair|pairing|paircode|pair\s*code|code|link|connect)\b/i.test(text) || /^\+?[\d\s\-()]{7,20}$/.test(text)) {
    return sendJoinGroupMessage(msg.chat.id, msg.message_id);
  }
});

// ========== POLLING ERROR HANDLER ==========
bot.on('polling_error', (error) => {
  console.error('Polling error:', error);
});

// ========== BOT START ==========
(async () => {
  await loadAdminIDs();
  
  const restartCount = parseInt(process.env.RESTART_COUNT || 0);
  console.log(`RESTART #${restartCount + 1}`);
  process.env.RESTART_COUNT = String(restartCount + 1);

  console.log('🤖 Telegram Bot is running...');
  console.log('✅ Bot Username: @MON_STAR_001');
  console.log('✅ Features: /pair, /start');
})();

// ========== PROCESS HANDLERS ==========
process.on("uncaughtException", (err) => {
  console.error('Uncaught Exception:', err);
});
process.on("unhandledRejection", (err) => {
  console.error('Unhandled Rejection:', err);
});
process.removeAllListeners("warning");
process.once('SIGINT', () => gracefulShutdown('SIGINT'));
process.once('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('message', (msg) => {
  if (msg === 'shutdown') gracefulShutdown('PM2_SHUTDOWN');
});
