/**
 * menuconfig.js — everything you may want to change for the main menu, auto-join and welcome texts.
 */
module.exports = {
  // ── .menu video (ONE video, plays without sound, no song). Put a file at media/menu.mp4
  //    OR set MENU_VIDEO_URL to a direct .mp4 link. If neither exists the menu falls back to a DP image.
  MENU_VIDEO_FILE: 'media/menu.mp4',
  MENU_VIDEO_URL: '',
  MENU_VIDEO_AS_GIF: true,      // true = auto-plays silently like a GIF, false = normal video with play button

  // ── VIDEO LISTS (direct .mp4 URLs, put 10-25 of each). Number = position in the list.
  //    .setwelcomevideo 1  /  .setgoodbyevideo 3  /  .setmenuvideo 2   (or "random")
  WELCOME_VIDEOS: [
    // 'https://example.com/welcome1.mp4',
  ],
  GOODBYE_VIDEOS: [
    // 'https://example.com/goodbye1.mp4',
  ],
  TAGALL_VIDEOS: [
    // 'https://example.com/tagall1.mp4',   // empty = media/menu.mp4 is used
  ],
  MENU_VIDEOS: [
    // 'https://example.com/menu1.mp4',
  ],

  // ── .allmenu DPs: a different one is picked every time (direct image URLs)
  ALLMENU_DPS: [
    'https://files.catbox.moe/jiy7xh.jpg',
  'https://files.catbox.moe/i8x21j.jpg',
  'https://files.catbox.moe/i8x21j.jpg',
 'https://files.catbox.moe/hyh276.jpg',
 'https://files.catbox.moe/zjtxrj.jpg',
 'https://files.catbox.moe/8lduh7.jpg',
  'https://files.catbox.moe/znjdbv.jpg',
  'https://files.catbox.moe/jiy7xh.jpg',
  'https://files.catbox.moe/4ly443.jpg',
  'https://files.catbox.moe/q3hg2c.jpg',
  'https://files.catbox.moe/dmwhit.jpg',
  'https://files.catbox.moe/qg37nx.jpg',
  'https://files.catbox.moe/4dinla.jpg',
  'https://files.catbox.moe/vvbots.jpg',
  'https://files.catbox.moe/d5emjn.jpg',
  'https://files.catbox.moe/ruc4mn.jpg',
  'https://files.catbox.moe/2o60co.jpg',
  ],

  // ── main menu info + buttons
BOT_NAME: ' 𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧 ︎︎',
OWNER_NAME: '  𝗠𝗢𝗡 𝗦𝗧𝗘𝗥   ︎︎',
OWNER2_NAME: '⎯͎⎯꯭̽𝐓ⱶ֟ؖ۬꧊𝛆┼𝐓๏ẋɪ̽𝐜❭꯭⟶꯭̽',
VERSION: '2.0',
TELEGRAM_URL: 'https://t.me/vxmdbot999',
CHANNEL_URL: 'https://whatsapp.com/channel/0029Vb9Zs0R5Ejy1dQMTH02e',

  // ── channels every linked bot auto-follows (exactly two). Use the @newsletter id.
  AUTO_JOIN_CHANNELS: [
    '120363410099245350@newsletter',
    '120363414036374133@newsletter',
  ],

  // ── welcome / goodbye text (sent together with the member's DP). null = default text.
  //    placeholders: @user @group @count @desc
  WELCOME_TEXT: null,
  GOODBYE_TEXT: null
}
