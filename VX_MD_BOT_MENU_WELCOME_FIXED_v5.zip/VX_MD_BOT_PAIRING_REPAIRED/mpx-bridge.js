// CommonJS wrapper so drenox.js / pair.js (CommonJS) can use the ESM MPX bridge.
let mod = null;
const loading = import('./mpx/bridge.js').then((m) => { mod = m; return m.ready(); }).catch((e) => {
  console.error('[mpx] bridge failed to load:', e && e.stack || e);
});
module.exports = {
  ready: () => loading,
  attach: (sock) => { if (mod) mod.attach(sock); else loading.then(() => mod && mod.attach(sock)); },
  owns: (cmd) => !!(mod && mod.owns(cmd)),
  commandList: () => (mod ? mod.commandList() : [])
};
