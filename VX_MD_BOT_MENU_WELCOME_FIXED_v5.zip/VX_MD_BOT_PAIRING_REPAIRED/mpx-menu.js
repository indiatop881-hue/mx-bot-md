/**
 * mpx-menu.js — menu helpers
 *
 *   group(prefix)       -> the ONE merged "Group Menu" (native group commands + MPX plugin commands:
 *                          protection, group status, welcome ...). Used by .allmenu and .groupmenu.
 *   beautify(text, o)   -> restyles any menu text: command rows are packed two per line, and
 *                          (o.index) a category index + total command count is added on top.
 */
const SMALL = Object.fromEntries('abcdefghijklmnopqrstuvwxyz'.split('').map((c, i) => [c, 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ'[i]]))
const sc = (t) => String(t).replace(/[a-z]/g, (c) => SMALL[c] || c)

const BULLET = '➤'
const SHORT = 13          // two commands share a line only if both are this short or shorter

// pack command names two per line  ->  ┃ ➤ .add   ➤ .kick
function rows(p, names) {
  // one command per line (clean, easy to read)
  return names.map((n) => `┃ ${BULLET} ${p}${sc(n)}`)
}

function section(title, p, names, note) {
  const lines = ['┃', `┃ ${title}`, ...rows(p, names)]
  if (note) lines.push(`┃ ┗ _${note}_`)
  return lines
}

function group(p = '.') {
  return [
    '╭━━〔 👥 ɢʀᴏᴜᴘ ᴍᴇɴᴜ 〕━━┈⊷',
    ...section('👮 *ᴍᴇᴍʙᴇʀs & ᴀᴅᴍɪɴs*', p,
      ['add', 'kick', 'kickall', 'promote', 'demote', 'promoteall', 'demoteall',
       'warn', 'resetwarn', 'checkadmin', 'listadmin', 'listonline']),
    ...section('📣 *ᴛᴀɢ & ᴄʜᴀᴛ*', p,
      ['tagall', 'everyone', 'ht', 'hidetag', 'tag', 'poll', 'del', 'delete', 'mute', 'unmute', 'chatbot', 'clearchatbot']),
    ...section('⚙️ *ɢʀᴏᴜᴘ sᴇᴛᴛɪɴɢs*', p,
      ['opengroup', 'closegroup', 'opentime', 'closetime', 'grouptime', 'groupopen', 'groupclose',
       'setname', 'setdesc', 'setppgc', 'linkgc', 'resetlink', 'groupjid', 'creategc', 'join', 'leave']),
    ...section('🛡️ *ᴘʀᴏᴛᴇᴄᴛɪᴏɴ*', p,
      ['antilink', 'antilinkgc', 'linklock', 'antiphising', 'antitoxic', 'antispam', 'antihidetag',
       'antibadword', 'antibot', 'antibug', 'antibill', 'antihijack', 'antiremove', 'antidelete',
       'antideletedm', 'antisticker', 'antistatus', 'antigroupstatus', 'antitagsw']),
    ...section('🖼️ *ᴀɴᴛɪ ᴍᴇᴅɪᴀ*', p, ['antimedia', 'antipic', 'antivideo', 'antivoice'],
      'antimedia: all / photo / video / voice / sticker / document / gif'),
    ...section('📢 *ɢʀᴏᴜᴘ sᴛᴀᴛᴜs*', p,
      ['gs', 'gcstatus', 'gstatus', 'swgc', 'swgcall', 'swgcv2all', 'delgcstatus', 'delgcstatusall'],
      'gs / gcstatus: post here  •  swgc: pick group  •  swgcv2all: all groups  •  delgcstatus: delete'),
    ...section('👋 *ᴡᴇʟᴄᴏᴍᴇ / ɢᴏᴏᴅʙʏᴇ*', p,
      ['welcome', 'setwelcome', 'setwelcomevideo', 'welcomevideos', 'goodbye', 'setgoodbye', 'dp', 'setmenuvideo']),
    ...section('🎵 *ᴍᴇᴅɪᴀ / ᴀɪ / ꜰᴜɴ*', p,
      ['song', 'play', 'video', 'aipic', 'ai', 'aivoice', 'anime', 'character', 'manga', 'kiss']),
    ...section('💥 *ʙᴜʟᴋ sᴛɪᴄᴋᴇʀ / ʟɪɴᴋ*', p,
      ['setlink', 'linkblast', 'stickerblast', 'videosticker', 'stopbulk']),
    ...section('🔐 *ᴏᴡɴᴇʀ ᴏɴʟʏ*', p, ['noring', 'bugblock', 'antibugblock', 'pairing']),
    '┃',
    `┃ 💡 Use *${p}<command> on / off*  (example: ${p}antilink on)`,
    '╰━━━━━━━━━━━━━━━━━━━━━┈⊷'
  ].join('\n')
}

// Re-style an existing menu text. Safe for any text: lines it does not know are left untouched.
function beautify(text, opts = {}) {
  const lines = String(text).split('\n')
  const out = []
  const ROW = /^┃✮│➣ (.+)$/
  const titles = []

  for (let i = 0; i < lines.length;) {
    const m = lines[i].match(ROW)
    if (!m) {
      const h = lines[i].match(/^╭━━〔 (.+?) 〕━━┈⊷$/)
      if (h && !/ᴀʟʟ ᴄᴏᴍᴍᴀɴᴅs|ᴄᴀᴛᴇɢᴏʀɪᴇs/.test(h[1])) titles.push(h[1])
      out.push(lines[i]); i++; continue
    }
    const run = []
    while (i < lines.length && ROW.test(lines[i])) { run.push(lines[i].match(ROW)[1]); i++ }
    for (const a of run) out.push(`┃ ${BULLET} ${a}`)
  }

  let result = out.join('\n')
  if (opts.index) {
    const idx = [
      '╭━━〔 📑 ᴄᴀᴛᴇɢᴏʀɪᴇs 〕━━┈⊷',
      ...titles.map((t, n) => `┃ ${String(n + 1).padStart(2, '0')} ❯ ${t}`),
      '┃',
      `┃ 📊 ᴛᴏᴛᴀʟ : *${countCommands(result)} ᴄᴏᴍᴍᴀɴᴅs*`,
      '╰━━━━━━━━━━━━━━━━━━━━━┈⊷',
      ''
    ].join('\n')
    // put the index right after the first (info) card
    const cut = result.indexOf('╰━━━━━━━━━━━━━━━┈⊷')
    if (cut !== -1) {
      const end = cut + '╰━━━━━━━━━━━━━━━┈⊷'.length
      result = result.slice(0, end) + '\n\n' + idx + result.slice(end)
    } else {
      result = idx + '\n' + result
    }
  }
  return result
}

function countCommands(text) {
  // every "➤ <prefix><command>" counts as one command
  return (String(text).match(/➤ [^\s➤]/g) || []).length
}

module.exports = { group, beautify, rows, sc }
