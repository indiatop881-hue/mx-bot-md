// ─────────────────────────────────────────────────────────────────────────────
// MPX plugin bridge for md_fixed_v3
//
// Runs the ORIGINAL MPX_MD_BOT plugin files (./plugins/*.js, untouched) on the
// WhatsApp sockets that md_fixed_v3 (pair.js / drenox.js) already creates.
// The dispatch rules below are copied from MPX lib/client.js so every command
// behaves the same as in MPX.
// ─────────────────────────────────────────────────────────────────────────────
import { jidNormalizedUser } from "@whiskeysockets/baileys";
import Serializer from "./lib/serialize.js";
import { forceLoadPlugins } from "./lib/plugins.js";
import { guardUpsert } from "./lib/xaf-antibug.js";
import { isNoRing } from "./lib/owner-guard.js";
import { db } from "./lib/client.js";
import { prewarmWelcome, getMenuVideo } from "./lib/video-store.js";
import config from "./config.js";

const CMD_TIMEOUT_MS = Number(process.env.CMD_TASK_TIMEOUT_MS) || 60_000;
const SONG_CMD_TIMEOUT_MS = Number(process.env.SONG_CMD_TIMEOUT_MS) || 240_000;
const TEXT_TIMEOUT_MS = Number(process.env.TEXT_TASK_TIMEOUT_MS) || 60_000;

const SONG_PUBLIC = ["song", "play", "ytplay", "music", "audio", "গান", "গানশুনাও", "শুনাও", "মিউজিক", "playch", "pch", "playsaluran", "searchthatsong", "sts", "carilagu", "yts", "ytsearch", "youtubesearch", "play3", "p3"];
const GAMING_PUBLIC = ["gaming", "gameon", "gameoff", "game", "games", "playgame", "gameplay"];
const ANTILINK_PUBLIC = ["antilink", "anti-link"];
// same prefixes md_fixed_v3 (drenox.js) accepts
const PREFIXES = [".", "/", "#", "!", "@"];

let snapshot = null;
let readyPromise = null;
const commandNames = new Set();
const attached = new WeakSet();
const serializers = new WeakMap();

export function ready() {
  if (!readyPromise) {
    readyPromise = (async () => {
      try { await db.ready?.(); } catch (e) { console.error("[mpx] db.ready failed:", e?.message || e); }
      snapshot = await forceLoadPlugins();
      for (const k of snapshot.commands.keys()) commandNames.add(String(k).toLowerCase());
      console.log(`[mpx] ✅ ${commandNames.size} command names loaded from MPX plugins`);
      return snapshot;
    })().catch((e) => { console.error("[mpx] plugin load failed:", e?.stack || e); readyPromise = null; });
  }
  return readyPromise;
}

export function owns(cmd) {
  return !!cmd && commandNames.has(String(cmd).toLowerCase());
}

export function commandList() {
  return [...commandNames];
}

function run(label, fn, ms) {
  let t;
  const timeout = new Promise((_, rej) => { t = setTimeout(() => rej(new Error(`${label} timed out`)), ms); });
  return Promise.race([Promise.resolve().then(fn), timeout])
    .catch((e) => console.error(`[mpx] ${label}:`, e?.message || e))
    .finally(() => clearTimeout(t));
}

function sessionIdOf(sock) {
  const jid = jidNormalizedUser(sock?.user?.id || "");
  return jid.split("@")[0] || "default";
}

function getSerializer(sock) {
  let s = serializers.get(sock);
  if (!s) {
    const sid = sessionIdOf(sock);
    sock.sessionId = sid;
    s = new Serializer(sock, sid);
    serializers.set(sock, s);
  }
  return s;
}

async function onMessage(sock, upsert) {
  if (!snapshot) await ready();
  if (!snapshot) return;

  const safe = await guardUpsert(sock, upsert);
  if (!safe) return;
  const { messages, type } = safe || {};
  if (type !== "notify" || !messages?.length) return;
  const raw = messages[0];
  if (!raw?.message) return;

  let msg;
  try { msg = getSerializer(sock).serializeSync(raw) ?? raw; } catch (e) { msg = raw; }
  if (!msg) return;

  if (msg.from?.endsWith("@newsletter")) return;

  if (msg.from === "status@broadcast") {
    for (const p of snapshot.message || []) run(`status ${p.command || p.name || "plugin"}`, () => p.exec(msg), TEXT_TIMEOUT_MS);
    return;
  }

  const body = String(msg.body || "");
  const prefix = PREFIXES.find((p) => body.startsWith(p)) || config.prefix || ".";
  // md_fixed_v3 keeps its own public/private switch on the socket
  const modeOn = sock.public !== false;

  if (body.startsWith(prefix) && (modeOn || msg.isFromMe)) {
    const trimmed = body.slice(prefix.length).trim();
    const spaceAt = trimmed.indexOf(" ");
    const rawCmd = spaceAt === -1 ? trimmed : trimmed.slice(0, spaceAt);
    const cmd = rawCmd.toLowerCase();
    const args = spaceAt === -1 ? "" : trimmed.slice(spaceAt + 1);
    const hasSecondPrefix = trimmed.startsWith(prefix);

    if (cmd && !hasSecondPrefix) {
      const plugin = snapshot.commands.get(cmd);
      const publicSong = msg.isGroup === true && SONG_PUBLIC.includes(cmd);
      const publicGaming = msg.isGroup === true && GAMING_PUBLIC.includes(cmd);
      const publicAntiLink = msg.isGroup === true && ANTILINK_PUBLIC.includes(cmd);
      const declaredOwnerAccess = Boolean(plugin?.isOwner && msg?.isOwner);
      const declaredGroupAccess = Boolean(plugin?.isGroup && msg?.isGroup && (!plugin?.isAdmin || msg?.isAdmin || msg?.isOwner));
      const declaredPublicAccess = Boolean(plugin && !plugin.isOwner && !plugin.isGroup && !plugin.isAdmin);

      if (plugin && (modeOn || msg.isFromMe || publicSong || publicGaming || publicAntiLink || declaredOwnerAccess || declaredGroupAccess || declaredPublicAccess)) {
        run(`cmd "${cmd}"`, () => plugin.exec(msg, args), publicSong ? SONG_CMD_TIMEOUT_MS : CMD_TIMEOUT_MS);
      }
    }
  }

  if (body && snapshot.text.length > 0) {
    for (const p of snapshot.text) run("text plugin", () => p.exec(msg), TEXT_TIMEOUT_MS);
  }
  if (snapshot.message?.length > 0) {
    for (const p of snapshot.message) run("message plugin", () => p.exec(msg), TEXT_TIMEOUT_MS);
  }
}

const mdCache = new Map(); // groupJid -> { md, t }
async function cachedMetadata(sock, jid) {
  const c = mdCache.get(jid);
  if (c && Date.now() - c.t < 60000) return c.md;
  try {
    if (typeof sock.groupMetadata !== "function") return c?.md || {};
    const md = await Promise.race([
      sock.groupMetadata(jid),
      new Promise((_, rej) => setTimeout(() => rej(new Error("groupMetadata timeout")), 5000)),
    ]);
    mdCache.set(jid, { md, t: Date.now() });
    return md || {};
  } catch { return c?.md || {}; }
}

async function onParticipants(sock, event) {
  if (!snapshot) await ready();
  if (!snapshot) return;
  const groupJid = event?.id || event?.groupJid || "";
  if (!groupJid) return;
  const md = await cachedMetadata(sock, groupJid);
  const incoming = (event.participants || [])
    .map((p) => (typeof p === "string" ? p : p?.id || p?.jid || ""))
    .filter(Boolean);
  const enriched = {
    ...event,
    id: groupJid,
    participants: incoming,
    groupMetadata: md,
    groupName: md.subject || "",
    groupSize: Array.isArray(md.participants) ? md.participants.length : 0,
    action: event.action || "",
    sessionId: sessionIdOf(sock),
  };
  const tasks = (snapshot.all || [])
    .filter((p) => p?.on === "group-participants.update" && typeof p.exec === "function")
    .map((p) => p.exec(null, enriched, sock).catch((e) => console.error("[mpx] group-participants plugin:", e?.message)));
  await Promise.allSettled(tasks);
}

async function onCall(sock, callData) {
  try {
    const sid = sessionIdOf(sock);
    const s = db.get(sid, "setting:antiCall", undefined);
    const legacy = db.get(sid, "anticall", undefined);
    const antiCallEnabled = s === true || legacy === true || legacy?.anticall === true || legacy?.anticall === "true";
    if (!antiCallEnabled && !isNoRing(sock)) return;
    for (const call of Array.isArray(callData) ? callData : [callData]) {
      if (call.isOffer || call.status === "offer") {
        const from = call.from || call.chatId;
        if (sock.rejectCall) sock.rejectCall(call.id, from).catch(() => {});
        else if (sock.updateCallStatus) sock.updateCallStatus(call.id, "reject").catch(() => {});
      }
    }
  } catch (e) { console.error("[mpx] call handler:", e?.message || e); }
}

export function attach(sock) {
  if (!sock?.ev || attached.has(sock)) return;
  attached.add(sock);
  ready();
  // pre-download the next welcome videos in the background so the first join is instant
  setTimeout(() => { try { prewarmWelcome(sessionIdOf(sock), 0).catch(() => {}); getMenuVideo(sessionIdOf(sock)).catch(() => {}); } catch {} }, 3000);
  const wrap = (name, fn) => sock.ev.on(name, (...a) => { Promise.resolve().then(() => fn(sock, ...a)).catch((e) => console.error(`[mpx] ${name}:`, e?.message || e)); });
  wrap("messages.upsert", onMessage);
  wrap("group-participants.update", onParticipants);
  wrap("call", onCall);
}
