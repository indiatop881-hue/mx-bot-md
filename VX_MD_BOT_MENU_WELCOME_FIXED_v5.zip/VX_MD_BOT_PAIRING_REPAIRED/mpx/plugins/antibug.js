import { Module } from "../lib/plugins.js";
import { getAntiBug, setAntiBug, setAntiBugAll } from "../lib/xaf-antibug.js";

async function admin(m) {
  if (!m.isGroup) {
    await m.send("❌ Ye command sirf group me chalta hai.");
    return false;
  }
  await m.loadGroupInfo();
  if (!m.isAdmin && !m.isFromMe) {
    await m.send("❌ Sirf group admin ye setting badal sakta hai.");
    return false;
  }
  return true;
}

const line = (c) =>
  `${c.on ? "✅" : "❌"} Anti Bug (bug message delete)\n` +
  `${c.kick ? "✅" : "❌"} Kick (bhejne wale ko hatao)\n` +
  `${c.close ? "✅" : "❌"} Close (group band karo)`;

// .antibug on|off  /  .antibug kick on|off  /  .antibug close on|off
Module({
  command: "antibug",
  aliases: ["antivirus", "anticrash", "antibugs"],
  package: "group",
  description: "Bug/virus/crash message delete + sender kick + group close",
})(async (m, args = "") => {
  if (!(await admin(m))) return;

  const p = String(args).trim().toLowerCase().split(/\s+/).filter(Boolean);

  if (p.length === 1 && (p[0] === "on" || p[0] === "off")) {
    setAntiBugAll(m.from, p[0] === "on");
    return m.send(
      (p[0] === "on" ? "🛡️ Anti Bug ALL ON\n\n" : "❌ Anti Bug ALL OFF\n\n") + line(getAntiBug(m.from))
    );
  }

  if (p.length === 2 && ["kick", "close"].includes(p[0]) && ["on", "off"].includes(p[1])) {
    setAntiBug(m.from, p[0], p[1] === "on");
    return m.send(`${p[1] === "on" ? "✅" : "❌"} ${p[0]} ${p[1].toUpperCase()}\n\n` + line(getAntiBug(m.from)));
  }

  return m.send(
    `🛡️ *ANTI BUG*\n\n${line(getAntiBug(m.from))}\n\n` +
      "Use:\n.antibug on / off\n.antibug kick on / off\n.antibug close on / off\n\n" +
      "ℹ️ Bot ko group admin banayein, tabhi delete / kick / close hoga.\n" +
      "Bug message bot ke andar kabhi nahi ghusta (admin ho ya nahi)."
  );
});
