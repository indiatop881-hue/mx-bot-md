import { Module } from "../lib/plugins.js";
import fs from "fs";
import path from "path";
import { isOwnerMessage, sleep } from "./groupstatus.js";

// Same data file that .gstatus / .delgcstatus use (last Group Status key per group).
const DB = path.join(process.cwd(), "data", "delgcstatus.json");

function readDb() {
  try {
    if (!fs.existsSync(DB)) return {};
    return JSON.parse(fs.readFileSync(DB, "utf8")) || {};
  } catch (error) {
    console.error("[delgcstatusall] DB read failed:", error?.message || error);
    return {};
  }
}

function writeDb(data) {
  try {
    fs.mkdirSync(path.dirname(DB), { recursive: true });
    fs.writeFileSync(DB, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error("[delgcstatusall] DB write failed:", error?.message || error);
  }
}

/*
|--------------------------------------------------------------------------
| DELGCSTATUSALL  (.delgcstatusall / .delallgcstatus)
|--------------------------------------------------------------------------
| Owner only. Deletes the Group Status that this bot posted (via .gstatus /
| .swgc / .swgcall / .swgcv2all) in EVERY group where one is remembered.
|--------------------------------------------------------------------------
*/
Module({
  command: "delgcstatusall",
  aliases: ["delallgcstatus", "delgstatusall", "dgsall"],
  package: "group",
  description: "Delete the Group Status posted by this bot in all groups (owner only)",
  usage: ".delgcstatusall",
})(async (message) => {
  try {
    if (!isOwnerMessage(message)) {
      return message.send("❌ Only the bot owner can use .delgcstatusall.");
    }

    const data = readDb();
    const entries = Object.entries(data).filter(([jid, v]) => jid.endsWith("@g.us") && v?.key?.id);

    if (!entries.length) {
      return message.send("ℹ️ No saved Group Status of this bot was found in any group.");
    }

    await message.react?.("⏳");
    await message.send("⏳ Deleting group statuses posted by this bot...");

    let ok = 0;
    let fail = 0;

    for (const [groupId, value] of entries) {
      try {
        const key = { ...value.key, remoteJid: value.key.remoteJid || groupId, fromMe: true };
        await message.conn.sendMessage(groupId, { delete: key });
        delete data[groupId];
        ok++;
      } catch (error) {
        console.error("[delgcstatusall]", groupId, error?.message || error);
        fail++;
      }
      await sleep(700);
    }

    writeDb(data);
    await message.react?.(fail ? "⚠️" : "✅");
    return message.send(`✅ Done\n🗑️ Deleted: ${ok}\n❌ Failed: ${fail}`);
  } catch (error) {
    console.error("[delgcstatusall]", error);
    await message.react?.("❌");
    return message.send("❌ *Failed to delete Group Statuses*\n\n" + (error?.message || error));
  }
});
