import os from "os";
import fs from "fs";
import path from "path";
import axios from "axios";
import { db } from "../lib/client.js";
import { Module, getEffectiveCommands } from "../lib/plugins.js";
import config from "../config.js";
import { sendNativeButtons } from "../lib/native-buttons.js";
import { getMenuVideo } from "../lib/video-store.js";

/*
 * .menu  — taken from VX_MD_BOT_SECURED.zip (plugins/menu.js), same look, same buttons:
 *   [ 📜 All Menu ]  -> .allmenu
 *   [ 📲 Telegram Pair ] -> .telegrampair
 *   [ 📢 CHANNEL ]   -> opens the channel link
 * Runs through the MPX bridge, so it does not wait for the old heavy command handler.
 */

const runtime = (secs) => {
  const pad = (s) => String(s).padStart(2, "0");
  return `${pad(Math.floor(secs / 3600))}h ${pad(Math.floor((secs % 3600) / 60))}m ${pad(Math.floor(secs % 60))}s`;
};

/* header photo (only used when there is no menu video) */
const DEFAULT_MENU_IMAGES = [
  "https://files.catbox.moe/jiy7xh.jpg",
  "https://files.catbox.moe/i8x21j.jpg",
  "https://files.catbox.moe/hyh276.jpg",
  "https://files.catbox.moe/zjtxrj.jpg",
  "https://files.catbox.moe/8lduh7.jpg",
  "https://files.catbox.moe/znjdbv.jpg",
  "https://files.catbox.moe/4ly443.jpg",
  "https://files.catbox.moe/q3hg2c.jpg",
  "https://files.catbox.moe/dmwhit.jpg",
  "https://files.catbox.moe/qg37nx.jpg",
  "https://files.catbox.moe/4dinla.jpg",
  "https://files.catbox.moe/d5emjn.jpg",
  "https://files.catbox.moe/ruc4mn.jpg",
  "https://files.catbox.moe/2o60co.jpg",
];
const _imgCache = new Map();
async function fetchMenuImage(url) {
  if (!url) return null;
  if (_imgCache.has(url)) return _imgCache.get(url);
  try {
    const res = await axios.get(url, { responseType: "arraybuffer", timeout: 8000, maxContentLength: 8 * 1024 * 1024 });
    const buf = Buffer.from(res.data);
    _imgCache.set(url, buf);
    return buf;
  } catch (e) {
    console.warn("[menu] image URL fetch failed:", url, e?.message || e);
    return null;
  }
}
async function resolveMenuImage() {
  const url = DEFAULT_MENU_IMAGES[Math.floor(Math.random() * DEFAULT_MENU_IMAGES.length)];
  return fetchMenuImage(url);
}

/* total command count = MPX plugin commands + the bot's own (drenox.js) commands */
let _nativeCount = null;
function nativeCommandCount() {
  if (_nativeCount !== null) return _nativeCount;
  try {
    const src = fs.readFileSync(path.join(process.cwd(), "drenox.js"), "utf8");
    const set = new Set();
    for (const m of src.matchAll(/^\s*case\s+['"]([a-z0-9_\-]{2,25})['"]\s*:/gim)) set.add(m[1]);
    _nativeCount = set.size;
  } catch { _nativeCount = 0; }
  return _nativeCount;
}
function totalCommandCount() {
  let mpx = 0;
  try {
    mpx = new Set(getEffectiveCommands().filter((c) => c && c.command && c.command !== "undefined").map((c) => c.command)).size;
  } catch {}
  return mpx + nativeCommandCount();
}

const DEFAULT_TELEGRAM_PAIR_LINK = "https://t.me/vxmdbot999";
function getTelegramPairLink() {
  const envLink = String(process.env.TELEGRAM_PAIR_LINK || DEFAULT_TELEGRAM_PAIR_LINK).trim();
  return envLink || DEFAULT_TELEGRAM_PAIR_LINK;
}
const WA_CHANNEL_URL = process.env.WA_CHANNEL_LINK || "https://whatsapp.com/channel/0029Vb9Zs0R5Ejy1dQMTH02e";

const withTimeout = (p, ms, label) =>
  Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error(label + " timed out")), ms))]);

/* ---------------------------------------------------------------------- */
/* MAIN MENU (.menu)                                                      */
/* ---------------------------------------------------------------------- */
Module({
  command: "menu",
  aliases: ["listmenu"],
  package: "general",
  description: "Main menu — All Menu aur Telegram Pair buttons",
})(async (message) => {
  const sock = message.conn;
  const prefix = config.prefix || ".";
  try {
    const isPublic = sock?.public !== false;
    const senderJid = message.sender || message.key?.participant || message.key?.remoteJid;
    const senderNum = String(senderJid || "").split("@")[0].split(":")[0] || "User";
    const totalCommands = totalCommandCount();
    const nowText = new Date().toLocaleString("en-GB", { timeZone: "Africa/Lagos" });

    const menuText = `
┏━━◆ ✦ 𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧 ✦ ◆━━┓
┃ ⧎ ʜᴇʟʟᴏ  @${senderNum}
┃ ⧎ ʙᴏᴛ ɴᴀᴍᴇ 「 *𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧* 」
┃ ⧎ ᴠᴇʀsɪᴏɴ : *1.0.0*
┃ ⧎ ᴏᴡɴᴇʀ : 𝗠𝗢𝗡 𝗦𝗧𝗘𝗥  
┃ ⧎ ᴍᴏᴅᴇ : *${isPublic ? "PUBLIC" : "PRIVATE"}*
┃ ⧎ ʀᴜɴᴛɪᴍᴇ : ${runtime(process.uptime())}
┃ ⧎ ᴘʀᴇғɪx : 「 ${prefix} 」
┃ ⧎ ᴘʟᴀᴛғᴏʀᴍ : ${os.platform()}
┃ ⧎ ᴄᴏᴍᴍᴀɴᴅs : ${totalCommands} total
┃ 🕒 ${nowText}
┗━━━━━━━━━━━━━━━━━━━━┛

❖═━═══𖠁𐂃𖠁══━═❖
👑 Owner    : 𝗠𝗢𝗡 𝗦𝗧𝗘𝗥
👑 2nd Owner: 𝗟𝗢𝗖𝗞 𝗕𝗜𝗧 𝗚𝗔𝗡𝗚
❖═━═══𖠁𐂃𖠁══━═❖`;

    // Video first (silent GIF-style). Photo is only downloaded when there is no video.
    let headerVideo = null;
    try {
      headerVideo = await getMenuVideo(message.botnum || sock?.user?.id);
    } catch (e) {
      console.warn("[menu] video load failed:", e?.message || e);
    }
    let headerImage = null;
    if (!headerVideo) {
      try { headerImage = await resolveMenuImage(); } catch {}
    }

    await withTimeout(
      sendNativeButtons(sock, message.from, {
        title: "",
        text: menuText,
        footer: "⚙️ Powered by 𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧 | © 2026",
        video: headerVideo,
        image: headerImage,
        buttons: [
          { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📜 All Menu", id: `${prefix}allmenu` }) },
          { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📲 Telegram Pair", id: `${prefix}telegrampair` }) },
          { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "📢 CHANNEL", url: WA_CHANNEL_URL, merchant_url: WA_CHANNEL_URL }) },
        ],
        contextInfo: {
          mentionedJid: senderJid ? [senderJid] : [],
          forwardingScore: 2,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363410099245350@newsletter",
            newsletterName: "© 𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧",
            serverMessageId: 6,
          },
        },
      }),
      20000,
      "menu buttons"
    );

  } catch (err) {
    console.error("❌ Main menu error:", err?.stack || err?.message || err);
    try {
      await sock.sendMessage(message.from, {
        text:
          `┏━━◆ *𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧 - 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔* ◆━━┓\n` +
          `│❖ ${prefix}allmenu  → poori command list\n` +
          `│❖ ${prefix}telegrampair  → Telegram pair link\n` +
          `┗━━━━━━━━━━━━━━━━━━━━┛`,
      });
    } catch {}
  }
});

/* ---------------------------------------------------------------------- */
/* TELEGRAM PAIR LINK (.telegrampair) — target of the menu button         */
/* ---------------------------------------------------------------------- */
Module({
  command: "telegrampair",
  aliases: ["tgpair", "telepair", "telegram"],
  package: "general",
  description: "Telegram pair bot ka link bhejta hai",
})(async (message) => {
  try {
    await message.conn.sendMessage(
      message.from,
      { text: getTelegramPairLink() },
      { quoted: message.key ? { key: message.key, message: { conversation: "Telegram Pair" } } : undefined }
    );
  } catch (err) {
    console.error("❌ Telegram pair error:", err?.stack || err?.message || err);
  }
});
