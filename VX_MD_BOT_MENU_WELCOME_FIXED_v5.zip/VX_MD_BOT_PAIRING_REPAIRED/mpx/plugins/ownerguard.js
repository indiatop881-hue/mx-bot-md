import { Module } from "../lib/plugins.js";
import { isNoRing, setNoRing, isBugBlock, setBugBlock } from "../lib/owner-guard.js";

const ownerOnly = async (m) => {
  if (m.isFromMe || m.isOwner) return true;
  await m.send("❌ Ye command sirf bot owner ke liye hai.");
  return false;
};

const parse = (args) => String(args || "").trim().toLowerCase().split(/\s+/)[0];

// .noring on / off  -> koi bhi (group member / DM) call kare to ring nahi aayegi
Module({
  command: "noring",
  aliases: ["anticall", "rejectcall", "antiring", "ringoff"],
  package: "owner",
  description: "Call/ring band: ON = koi bhi call kare to auto reject (ring nahi), OFF = call normal dikhegi",
  isOwner: true,
})(async (m, args = "") => {
  if (!(await ownerOnly(m))) return;
  const sock = m.conn;
  const v = parse(args);
  if (v === "on") {
    setNoRing(sock, true);
    return m.send("📵 *NO RING ON*\n\nAb koi bhi member ya contact call/ring karega to auto reject hogi, baar baar disturb nahi hoga.\n\nWapas call dekhne ke liye: *.noring off*");
  }
  if (v === "off") {
    setNoRing(sock, false);
    return m.send("📞 *NO RING OFF*\n\nAb call normal dikhegi / ring aayegi.");
  }
  return m.send(`📵 *NO RING*: ${isNoRing(sock) ? "✅ ON" : "❌ OFF"}\n\nUse:\n.noring on\n.noring off`);
});

// .bugblock on / off -> bug/virus bhejne wale ko block + uska message delete
Module({
  command: "bugblock",
  aliases: ["antibugblock", "blockbug", "virusblock"],
  package: "owner",
  description: "Bug/virus bhejne wale ko auto block + uska bug message delete",
  isOwner: true,
})(async (m, args = "") => {
  if (!(await ownerOnly(m))) return;
  const sock = m.conn;
  const v = parse(args);
  if (v === "on") {
    setBugBlock(sock, true);
    return m.send("🛡️ *BUG BLOCK ON*\n\nGroup ya inbox me jo bhi bug/virus message bhejega:\n🗑️ uska message delete\n🚫 wo number block\n\n(Group admin ho to message sabke liye delete hota hai, warna aapke chat se.)");
  }
  if (v === "off") {
    setBugBlock(sock, false);
    return m.send("❌ *BUG BLOCK OFF*");
  }
  return m.send(`🛡️ *BUG BLOCK*: ${isBugBlock(sock) ? "✅ ON" : "❌ OFF"}\n\nUse:\n.bugblock on\n.bugblock off`);
});
