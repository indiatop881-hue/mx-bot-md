import fs from "fs";
import os from "os";
import path from "path";
import pino from "pino";
import makeWASocket, {
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers,
} from "@whiskeysockets/baileys";
import { Module } from "../lib/plugins.js";
import { sendNativeButtons } from "../lib/native-buttons.js";
import { isPairingOn, setPairing, pairingKey } from "../lib/pairing-toggle.js";

const CODE_LIFETIME_MS = 90_000; // code ~60s chalta hai, thoda extra rakha
const cooldown = new Map(); // number -> last request time
const COOLDOWN_MS = 30_000;

const ownerOnly = async (m) => {
  if (m.isFromMe || m.isOwner) return true;
  await m.send("❌ Ye command sirf bot owner ke liye hai.");
  return false;
};

const fmtCode = (raw) => {
  const c = String(raw || "").replace(/[^A-Za-z0-9]/g, "");
  return c.length === 8 ? `${c.slice(0, 4)}-${c.slice(4)}` : c;
};

/** Alag temporary socket se is number ka pairing code banao (bot ka main session nahi chhedta). */
async function makePairCode(number) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `vx-pair-${number}-`));
  const { state, saveCreds } = await useMultiFileAuthState(dir);
  const { version } = await fetchLatestBaileysVersion();
  const logger = pino({ level: "silent" });

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    browser: Browsers.macOS("Safari"),
    markOnlineOnConnect: false,
    syncFullHistory: false,
  });
  sock.ev.on("creds.update", saveCreds);

  const cleanup = () => {
    try { sock.ev.removeAllListeners(); } catch {}
    try { sock.ws?.close(); } catch {}
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}
  };
  setTimeout(cleanup, CODE_LIFETIME_MS);

  try {
    await new Promise((r) => setTimeout(r, 2500));
    const raw = await sock.requestPairingCode(number);
    return fmtCode(raw);
  } catch (e) {
    cleanup();
    throw e;
  }
}

// .pairing on / off / (khali) -> code
Module({
  command: "pairing",
  aliases: ["pairingcode", "paircode"],
  package: "owner",
  description: "Pairing code: .pairing on / off, ON hone par .pairing ya .pairing <number> se code milega (DM aur group dono me, sirf owner)",
  isOwner: true,
})(async (m, args = "") => {
  if (!(await ownerOnly(m))) return;
  const sock = m.conn;
  const v = String(args || "").trim().toLowerCase().split(/\s+/)[0];

  if (v === "on") {
    setPairing(sock, true);
    return m.send(
      "🔐 *PAIRING ON*\n\nAb *.pairing* bhejoge to isi number par pairing code aayega, neeche copy button ke saath.\n\nBand karne ke liye: *.pairing off*"
    );
  }
  if (v === "off") {
    setPairing(sock, false);
    return m.send("🔒 *PAIRING OFF*\n\nAb pairing code nahi diya jayega.\nChalu karne ke liye: *.pairing on*");
  }

  if (!isPairingOn(sock)) {
    return m.send(
      "🔒 *PAIRING OFF hai.*\n\nCode lene ke liye pehle chalu karo:\n*.pairing on*\nphir *.pairing*"
    );
  }

  // .pairing 91XXXXXXXXXX -> us number ka code, bina number ke -> bot ka apna number
  const given = String(args || "").replace(/\D/g, "");
  const number = given.length >= 8 ? given : pairingKey(sock);
  const last = cooldown.get(number) || 0;
  const wait = COOLDOWN_MS - (Date.now() - last);
  if (wait > 0) return m.send(`⏳ ${Math.ceil(wait / 1000)} second ruk kar dobara try karo.`);
  cooldown.set(number, Date.now());

  let code;
  try {
    code = await makePairCode(number);
  } catch (e) {
    return m.send(`❌ Pairing code nahi ban paya: ${e?.message || e}`);
  }

  // DM me likha to usi chat me, group me likha to owner ki personal chat me (group me code leak na ho)
  const senderJid = String(m.sender || "");
  const selfJid = !m.isGroup
    ? m.from
    : senderJid.endsWith("@s.whatsapp.net")
      ? senderJid
      : `${pairingKey(sock)}@s.whatsapp.net`;
  const text =
    `🔐 *PAIRING CODE*\n\n📱 Number: +${number}\n\n🔑 *${code}*\n\n` +
    `WhatsApp → Linked Devices → Link a Device → _Link with phone number instead_ → ye code daalo.\n\n` +
    `⏰ Code lagbhag 60 second chalega.`;

  try {
    await sendNativeButtons(sock, selfJid, {
      text,
      footer: "MPX MD",
      buttons: [
        {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: `📋 Copy ${code}`,
            copy_code: code.replace(/-/g, ""),
          }),
        },
      ],
    });
  } catch (e) {
    await sock.sendMessage(selfJid, { text });
  }

  if (m.from !== selfJid) await m.send("✅ Pairing code aapki personal chat me bhej diya.");
});
