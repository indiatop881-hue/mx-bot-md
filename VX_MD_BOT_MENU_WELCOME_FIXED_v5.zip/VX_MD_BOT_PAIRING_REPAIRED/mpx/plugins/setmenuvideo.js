import { Module } from "../lib/plugins.js";
import { createRequire } from "module";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { isOwnerMessage } from "./groupstatus.js";

const require = createRequire(import.meta.url);
const { getSetting, setSetting } = require("../../Settings.js");
const menuConfig = require("../../menuconfig.js");
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const MENU_VIDEO_FILE = path.resolve(__dirname, "../../", menuConfig.MENU_VIDEO_FILE || "media/menu.mp4");

function currentUrls() {
  const saved = getSetting("bot", "menuVideoUrls", []);
  const runtime = Array.isArray(saved) ? saved : (saved ? [saved] : []);
  return [...runtime, ...(Array.isArray(menuConfig.MENU_VIDEOS) ? menuConfig.MENU_VIDEOS : [])]
    .map((u) => String(u || "").trim())
    .filter((u, i, all) => /^https?:\/\//i.test(u) && all.indexOf(u) === i);
}
function validDirectUrl(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) && /\.mp4(?:$|[?#])/i.test(url.pathname + url.search + url.hash);
  } catch { return false; }
}
function isVideoMessage(q) {
  return Boolean(q && (q.isVideo || q.mtype === "videoMessage" || q.type === "videoMessage" || /^video\//i.test(q.mimetype || q.msg?.mimetype || "")));
}
async function downloadQuotedVideo(message, quoted) {
  if (typeof quoted?.download === "function") {
    const result = await quoted.download();
    if (Buffer.isBuffer(result) && result.length) return result;
    if (result instanceof Uint8Array && result.length) return Buffer.from(result);
  }
  const sock = message.conn || message.client || message.sock;
  const fake = quoted?.fakeObj || quoted?.raw || quoted;
  if (sock && typeof sock.downloadMediaMessage === "function") {
    const result = await sock.downloadMediaMessage(fake);
    if (Buffer.isBuffer(result) && result.length) return result;
    if (result instanceof Uint8Array && result.length) return Buffer.from(result);
  }
  if (typeof message.downloadQuotedMedia === "function") {
    const result = await message.downloadQuotedMedia(quoted);
    if (Buffer.isBuffer(result) && result.length) return result;
  }
  throw new Error("Could not download the replied video. Try replying to a normal video message.");
}

Module({
  command: "setmenuvideo",
  aliases: ["menuvideo", "changemenuvideo"],
  package: "owner",
  description: "Set menu video by replying to a WhatsApp video or by direct MP4 URL",
  usage: ".setmenuvideo (reply to video) | <direct-mp4-url|number|random|list|clear>",
})(async (message, match = "") => {
  try {
    if (!isOwnerMessage(message)) return message.reply("❌ Only the bot owner can change the menu video.");
    const arg = String(match || "").trim();
    const lower = arg.toLowerCase();

    // Reply to a video and run .setmenuvideo: save it as the active local menu video.
    if (message.quoted && isVideoMessage(message.quoted) && (!arg || ["reply", "save", "set", "video"].includes(lower))) {
      const buffer = await downloadQuotedVideo(message, message.quoted);
      if (buffer.length < 1024) return message.reply("❌ Downloaded video is empty or too small. Please reply to another video.");
      if (buffer.length > 64 * 1024 * 1024) return message.reply("❌ Video is too large (maximum 64 MB). Please use a smaller video.");
      fs.mkdirSync(path.dirname(MENU_VIDEO_FILE), { recursive: true });
      const tempFile = `${MENU_VIDEO_FILE}.tmp`;
      fs.writeFileSync(tempFile, buffer);
      fs.renameSync(tempFile, MENU_VIDEO_FILE);
      setSetting("bot", "menuVideoUseLocal", true);
      setSetting("bot", "menuVideoNo", 0);
      return message.reply("✅ Replied WhatsApp video is now the MENU video!\n🎬 Run .menu to check it.\n🔗 To switch back to URL videos, use .setmenuvideo list then select a number or use random.");
    }

    let urls = currentUrls();
    if (!arg || lower === "list") {
      const localActive = getSetting("bot", "menuVideoUseLocal", false) && fs.existsSync(MENU_VIDEO_FILE);
      if (!urls.length) return message.reply(localActive ? "🎬 Current menu video: WhatsApp replied video (local file).\nReply to another video with .setmenuvideo to replace it." : "ℹ️ Menu video URL list is empty.\nAdd one with: *.setmenuvideo https://host/video.mp4*\nOr reply to a WhatsApp video with *.setmenuvideo*.");
      const selected = Number.parseInt(getSetting("bot", "menuVideoNo", 0), 10) || 0;
      const rows = urls.map((url, i) => `${i + 1}. ${i + 1 === selected && !localActive ? "✅ " : ""}${url}`).join("\n");
      return message.reply(`🎬 *MENU VIDEO URLS* (${urls.length})\n${localActive ? "Current source: replied WhatsApp video\n" : ""}\n${rows}\n\nSelect: *.setmenuvideo 2*\nRandom: *.setmenuvideo random*`);
    }
    if (["clear", "reset", "remove"].includes(lower)) {
      setSetting("bot", "menuVideoUrls", []);
      setSetting("bot", "menuVideoNo", 0);
      setSetting("bot", "menuVideoUseLocal", false);
      return message.reply("✅ Runtime menu video URLs cleared. menuconfig.js URLs / media/menu.mp4 fallback will be used.");
    }
    if (["random", "0", "auto"].includes(lower)) {
      if (!urls.length) return message.reply("❌ Pehle direct MP4 URL add karo, ya kisi WhatsApp video par reply karke .setmenuvideo chalao.");
      setSetting("bot", "menuVideoNo", 0);
      setSetting("bot", "menuVideoUseLocal", false);
      return message.reply("✅ Menu video RANDOM mode ON. Har .menu par list se video choose hoga.");
    }
    if (/^https?:\/\//i.test(arg)) {
      if (!validDirectUrl(arg)) return message.reply("❌ Direct MP4 URL do (URL ke end me .mp4 hona chahiye). Example: *.setmenuvideo https://host/video.mp4*");
      const saved = getSetting("bot", "menuVideoUrls", []);
      const runtime = Array.isArray(saved) ? saved : (saved ? [saved] : []);
      if (!runtime.includes(arg)) runtime.push(arg);
      setSetting("bot", "menuVideoUrls", runtime);
      const all = currentUrls();
      setSetting("bot", "menuVideoNo", all.indexOf(arg) + 1);
      setSetting("bot", "menuVideoUseLocal", false);
      return message.reply(`✅ Menu video URL added and selected.\n📹 Total URLs: ${all.length}\nUse *.setmenuvideo random* for random videos.`);
    }
    if (/^\d+$/.test(arg)) {
      const n = Number(arg);
      if (!urls.length) return message.reply("❌ Video list empty hai. Pehle MP4 URL add karo ya kisi WhatsApp video par reply karke .setmenuvideo chalao.");
      if (n < 1 || n > urls.length) return message.reply(`❌ Invalid number. Choose 1-${urls.length}, or use *.setmenuvideo random*.`);
      setSetting("bot", "menuVideoNo", n);
      setSetting("bot", "menuVideoUseLocal", false);
      return message.reply(`✅ Menu video #${n} selected.\n${urls[n - 1]}`);
    }
    return message.reply("❌ Usage:\n• Reply to a WhatsApp video with *.setmenuvideo*\n• .setmenuvideo https://host/video.mp4\n• .setmenuvideo 2\n• .setmenuvideo random\n• .setmenuvideo list\n• .setmenuvideo clear");
  } catch (error) {
    console.error("[setmenuvideo]", error?.stack || error);
    return message.reply(`❌ Menu video error: ${error?.message || error}`);
  }
});
