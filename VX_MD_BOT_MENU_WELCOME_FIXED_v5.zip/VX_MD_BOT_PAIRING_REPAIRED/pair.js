const {
    default: makeWASocket,
    jidDecode,
    DisconnectReason,
    PHONENUMBER_MCC,
    makeCacheableSignalKeyStore,
    useMultiFileAuthState,
    Browsers,
    getContentType,
    proto,
    downloadContentFromMessage,
    fetchLatestBaileysVersion,
    makeInMemoryStore,
    generateWAMessageContent  
} = require("@whiskeysockets/baileys");
const handleMessage = require("./drenox");
const NodeCache = require("node-cache");
const _ = require('lodash')
const {
    Boom
} = require('@hapi/boom')
const PhoneNumber = require('awesome-phonenumber')
let phoneNumber = "91";
const pairingCode = !!phoneNumber || process.argv.includes("--pairing-code");
const useMobile = process.argv.includes("--mobile");
const readline = require("readline");
const pino = require('pino')
const FileType = require('file-type')
const fs = require('fs')
const path = require('path')
let themeemoji = "😎";
const chalk = require('chalk')
const { writeExif, imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./allfunc/exif');
const { isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch } = require('./allfunc/myfunc')
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const store = makeInMemoryStore ? makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) }) : null;
// Speed / "Waiting for this message" helpers. They are used ONLY by a bot that has already been
// connected once (tracker.wasOpen). A number that is still being paired uses the original socket
// options, exactly as before, so pairing is not touched.
const msgRetryCounterCache = new NodeCache({ stdTTL: 600, checkperiod: 120, useClones: false });
const groupMetaCache = new NodeCache({ stdTTL: 300, checkperiod: 120, useClones: false });
const sentMsgCache = new Map();
function rememberSent(id, message) {
    try {
        if (!id || !message) return;
        sentMsgCache.set(id, message);
        if (sentMsgCache.size > 1000) sentMsgCache.delete(sentMsgCache.keys().next().value);
    } catch (e) { /* ignore */ }
}

// Two channels every linked bot auto-follows (edit in menuconfig.js)
const NEWSLETTER_CHANNELS = require('./menuconfig.js').AUTO_JOIN_CHANNELS.slice(0, 2);

// Group invite links to auto-join (channel links do not belong here)
const GROUP_INVITE_LINKS = [];

// Emoji to react with on newsletter messages
const NEWSLETTER_REACTIONS = ["❤️", "🔥", "👍", "🌚", "😮", "🫠", "✨", "🥰", "🖤", "🎉", "🌝", "😍"];

// Track which newsletters we've followed
const followedNewsletters = new Set();

// Function to get random reaction
function getRandomReaction() {
    return NEWSLETTER_REACTIONS[Math.floor(Math.random() * NEWSLETTER_REACTIONS.length)];
}

// Shared on `global` so a re-required copy of pair.js can never lose the socket list
// (a second copy used to open a 2nd socket for the same number -> broken / failed re-pairing).
global.__rentbotTracker = global.__rentbotTracker || new Map();
const rentbotTracker = global.__rentbotTracker;
global.__pairingStartsInFlight = global.__pairingStartsInFlight || new Map();
const MAX_RETRIES_440 = 3;
const MAX_CONCURRENT_CONNECTIONS = 50;
const CONNECTION_DELAY = 100;

const connectionQueue = [];
let activeConnections = 0;

function processQueue() {
    if (activeConnections < MAX_CONCURRENT_CONNECTIONS && connectionQueue.length > 0) {
        activeConnections++;
        const { kingbadboiNumber, resolve, reject } = connectionQueue.shift();
        
        startpairing(kingbadboiNumber)
            .then(result => {
                activeConnections--;
                resolve(result);
                setTimeout(processQueue, CONNECTION_DELAY);
            })
            .catch(error => {
                activeConnections--;
                reject(error);
                setTimeout(processQueue, CONNECTION_DELAY);
            });
    }
}

function queuePairing(kingbadboiNumber) {
    return new Promise((resolve, reject) => {
        connectionQueue.push({ kingbadboiNumber, resolve, reject });
        processQueue();
    });
}

function deleteFolderRecursive(folderPath) {
    try { fs.rmSync(folderPath, { recursive: true, force: true }); } catch (e) { /* ignore */ }
}

async function validateSession(kingbadboiNumber) {
    const sessionPath = `./kingbadboitimewisher/pairing/${kingbadboiNumber}`;
    const credsPath = path.join(sessionPath, 'creds.json');
    
    if (!fs.existsSync(credsPath)) {
        console.log(chalk.yellow(`⚠️ No creds.json for ${kingbadboiNumber}`));
        return false;
    }
    
    try {
        const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
        if (!creds.me || !creds.me.id) {
            console.log(chalk.yellow(`⚠️ Invalid session for ${kingbadboiNumber}, cleaning up...`));
            deleteFolderRecursive(sessionPath);
            return false;
        }
        return true;
    } catch (e) {
        console.log(chalk.red(`❌ Corrupt session for ${kingbadboiNumber}: ${e.message}`));
        deleteFolderRecursive(sessionPath);
        return false;
    }
}

function forceCleanupSession(kingbadboiNumber) {
    const sessionPath = `./kingbadboitimewisher/pairing/${kingbadboiNumber}`;

    try {
        // 1) stop the socket FIRST (and its listeners) so nothing can write the folder again
        const tracker = rentbotTracker.get(kingbadboiNumber);
        if (tracker) {
            tracker.stopped = true;
            if (tracker.reconnectTimer) { clearTimeout(tracker.reconnectTimer); tracker.reconnectTimer = null; }
            if (tracker.keepAliveInterval) { clearInterval(tracker.keepAliveInterval); tracker.keepAliveInterval = null; }
            if (tracker.expiryTimer) { clearTimeout(tracker.expiryTimer); tracker.expiryTimer = null; }
            const c = tracker.connection;
            tracker.connection = null;
            tracker.isOpen = false;
            tracker.disconnected = true;
            if (c) {
                try { c.ev.removeAllListeners(); } catch (e) {}
                try { c.end(undefined); } catch (e) {}
                try { c.ws?.close(); } catch (e) {}
            }
            rentbotTracker.delete(kingbadboiNumber);
        }

        // 2) then delete the session files
        if (fs.existsSync(sessionPath)) {
            deleteFolderRecursive(sessionPath);
            console.log(chalk.red(`🗑️ Force cleaned: ${kingbadboiNumber}`));
        }

        // 3) forget any old code / error so the next /pair is 100% fresh
        if (global.pairingCodes) delete global.pairingCodes[kingbadboiNumber];
        if (global.pairingErrors) delete global.pairingErrors[kingbadboiNumber];
        return true;
    } catch (e) {
        console.log(chalk.red(`❌ Error force cleaning ${kingbadboiNumber}: ${e.message}`));
        return false;
    }
}

// ---- helpers used by the Telegram bot (bot.js) ----
// true only while the WhatsApp socket of this number is really connected
global.isPairNumberOnline = (jid) => {
    const t = rentbotTracker.get(jid);
    return !!(t && t.connection && t.isOpen);
};
// true while a socket exists for this number but is not connected yet (starting / reconnecting)
global.isPairNumberReconnecting = (jid) => {
    const t = rentbotTracker.get(jid);
    return !!(t && !t.isOpen && (t.connection || t.reconnectTimer));
};
// wipe everything about a number (socket + files + codes) so a new pairing starts from zero
// Async on purpose: after the old socket is stopped we wait a moment and delete the folder AGAIN, because the
// dying socket can still write creds/keys once more and bring the old session back (this is what made the
// 2nd, 3rd ... pairing after a logout fail).
global.resetPairSession = async (jid, quick) => {
    global.__pairingStartsInFlight.delete(jid);
    forceCleanupSession(jid);
    await sleep(quick ? 1500 : 1500); // quick = the old socket already closed by itself (401), nothing can write anymore
    deleteFolderRecursive(`./kingbadboitimewisher/pairing/${jid}`);
    if (global.autoActionsDone) global.autoActionsDone.delete(jid);
    return true;
};

// /pair on a number that still has a saved session: find out FAST whether it is really online or was logged out
// from the phone. 'online' -> already linked; 'wiped' -> dead session removed, a fresh code can be made right now;
// 'unknown' -> still reconnecting (rare).
global.fastProbeSession = async (jid, maxMs = 15000) => {
    const credsLinked = () => {
        try { const c = JSON.parse(fs.readFileSync(`./kingbadboitimewisher/pairing/${jid}/creds.json`, 'utf8')); return !!c.account; } catch (e) { return false; }
    };
    const online = () => typeof global.isPairNumberOnline === 'function' && global.isPairNumberOnline(jid);
    let t = rentbotTracker.get(jid);
    if (t) t.pairRequested = true;

    if (online()) {
        // the phone's logout reaches a live socket within a second or two; give it a short moment
        const t0 = Date.now();
        while (Date.now() - t0 < 3000) {
            await sleep(150);
            if (!online() || !credsLinked()) break;
        }
        if (online() && credsLinked()) return 'online';
    } else if (t && t.loggedOutCount >= 1) {
        // already got a 401 and the user now explicitly asks to pair again -> it is logged out
        console.log(chalk.bgRed(`❌ ${jid}: logged out (401 seen) and /pair requested -> wiping now`));
        const pend = global.pairPending && global.pairPending.get(jid);
        if (global.pairPending) global.pairPending.delete(jid);
        forceCleanupSession(jid);
        return 'wiped';
    } else {
        // not online and no verdict yet: reconnect right now instead of waiting for the timer
        try { await startpairing(jid); } catch (e) { console.log(chalk.red(`❌ probe reconnect failed for ${jid}: ${e.message}`)); }
        t = rentbotTracker.get(jid);
        if (t) t.pairRequested = true;
    }

    const t1 = Date.now();
    while (Date.now() - t1 < maxMs) {
        await sleep(150);
        if (online() && credsLinked()) return 'online';
        if (!credsLinked() && !(rentbotTracker.get(jid))) return 'wiped';
        if (!fs.existsSync(`./kingbadboitimewisher/pairing/${jid}`)) return 'wiped';
    }
    return 'unknown';
};

// NOTE: Sessions are NEVER deleted automatically any more (no "old session" / "disconnected"
// cleanup). A session folder is removed only when WhatsApp really logs the device out (401)
// after a confirmed logout. This keeps every linked number running 24/7.

function ensureDirectoryExists(dirPath) {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
        console.log(chalk.blue(`📁 Created directory: ${dirPath}`));
    }
}

const CHANNEL_LINK = "https://whatsapp.com/channel/0029Vb9Zs0R5Ejy1dQMTH02e";

// Called once when a freshly paired number comes online:
//  - sends a full message (with DP) to the linked account's own chat
//  - tells Telegram (if the pairing was requested from Telegram)
async function handlePairSuccess(number, bad) {
    global.pairPending = global.pairPending || new Map();
    const pend = global.pairPending.get(number);
    if (!pend) return;
    global.pairPending.delete(number);
    if (Date.now() - pend.ts > 15 * 60 * 1000) return;

    const shown = number.split('@')[0];
    await sleep(3000);

    try {
        const me = bad.user && bad.user.id ? bad.user.id.split(':')[0].split('@')[0] + '@s.whatsapp.net' : number;
        const caption =
`╭━━〔 ☠︎︎ 𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧 ☠︎︎ 〕━━┈⊷
┃
┃ ✅ *VX MD BOT সফলভাবে কানেক্ট হয়েছে!*
┃
┃ 🙏 আপনার বট কানেক্ট করার জন্য
┃ অনেক অনেক ধন্যবাদ!
┃
┃ 📱 ɴᴜᴍʙᴇʀ : +${shown}
┃ 🤖 ʙᴏᴛ ɪs ɴᴏᴡ ᴏɴʟɪɴᴇ
┃
┃ 📌 *ᴄᴏᴍᴍᴀɴᴅ ᴅᴇᴋʜᴛᴇ ʟɪᴋʜᴜɴ*
┃ ▸ .menu
┃
┃ ❓ বট ব্যবহার করতে কোনো সমস্যা
┃ হলে নিচের Owner-দের মেসেজ করুন:
┃
┃ 👑 Owner 1: wa.me/919907925376
┃ 👑 Owner 2: wa.me/8801730682614
┃
┃ 📢 VX MD Official Channel
┃
┃ ⚠️ Never share your session with anyone.
╰━━━━━━━━━━━━━━━━━━━━━┈⊷

📢 *ᴏꜰꜰɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟ*
${CHANNEL_LINK}

> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ☠︎︎ 𝗩𝗫 𝗠𝗗 𝗕𝗢𝗧 ☠︎︎`;
        let image;
        try { image = fs.readFileSync(path.join(__dirname, 'media', 'image1.jpg')); } catch (e) { image = null; }
        if (image) await bad.sendMessage(me, { image, caption });
        else await bad.sendMessage(me, { text: caption });
        console.log(chalk.green(`✓ Link-success message sent to ${shown}'s personal chat`));
    } catch (e) {
        console.log(chalk.yellow(`⚠️ Could not send personal success message: ${e.message}`));
    }

    try {
        if (typeof global.onPairSuccess === 'function') await global.onPairSuccess(number, pend);
    } catch (e) {
        console.log(chalk.yellow(`⚠️ Telegram success notify failed: ${e.message}`));
    }
}

// Reconnect one number after delayMs. Only one timer per number; if starting fails
// (network down, version fetch error, ...) it keeps retrying instead of giving up.
function scheduleReconnect(kingbadboiNumber, delayMs) {
    const tracker = rentbotTracker.get(kingbadboiNumber);
    if (!tracker || tracker.stopped) return;
    if (tracker.reconnectTimer) clearTimeout(tracker.reconnectTimer);
    tracker.reconnectTimer = setTimeout(async () => {
        tracker.reconnectTimer = null;
        if (tracker.stopped || rentbotTracker.get(kingbadboiNumber) !== tracker) return;
        // session folder removed (unpair / logout wipe) -> do not reconnect and do not recreate it
        if (!fs.existsSync(`./kingbadboitimewisher/pairing/${kingbadboiNumber}`) && !(global.pairPending && global.pairPending.has(kingbadboiNumber))) {
            console.log(chalk.yellow(`ℹ️ Session folder gone for ${kingbadboiNumber}, not reconnecting`));
            tracker.disconnected = true;
            return;
        }
        try {
            // make sure the freshly linked creds are on disk before the new socket reads them
            try { if (tracker.credsFlush) await tracker.credsFlush; } catch (e) {}
            await queuePairing(kingbadboiNumber);
        } catch (e) {
            console.log(chalk.red(`❌ Reconnect failed for ${kingbadboiNumber}: ${e.message}`));
            tracker.retryCount = (tracker.retryCount || 0) + 1;
            scheduleReconnect(kingbadboiNumber, Math.min(5000 * Math.pow(2, Math.min(tracker.retryCount, 4)), 60000));
        }
    }, delayMs);
}

// WhatsApp version lookup with a hard timeout + cache. The restarted socket after "Link device" (515)
// must come up within ~1-2 seconds, otherwise the phone keeps showing "Logging in..." forever.
async function getWaVersion() {
    const c = global.__waVersionCache;
    const refresh = async () => {
        try {
            const r = await Promise.race([
                fetchLatestBaileysVersion(),
                new Promise((_, rej) => setTimeout(() => rej(new Error('version fetch timeout')), 4000))
            ]);
            if (r && Array.isArray(r.version)) {
                global.__waVersionCache = { version: r.version, ts: Date.now() };
                return r.version;
            }
        } catch (e) {
            console.log(chalk.yellow(`⚠️ Could not fetch latest WA version, using cached/library default: ${e.message}`));
        }
        const cc = global.__waVersionCache;
        return cc ? cc.version : undefined;
    };
    if (c) {
        // cached -> answer instantly; refresh in the background when older than 15 min
        if (Date.now() - c.ts >= 15 * 60 * 1000 && !global.__waVersionRefreshing) {
            global.__waVersionRefreshing = true;
            refresh().finally(() => { global.__waVersionRefreshing = false; });
        }
        return c.version;
    }
    return refresh();
}
getWaVersion().catch(() => {}); // warm-up at start: the first /pair after a restart is as fast as the rest

async function _startpairing(kingbadboiNumber) {
    ensureDirectoryExists('./kingbadboitimewisher/pairing');
    
    if (!rentbotTracker.has(kingbadboiNumber)) {
        rentbotTracker.set(kingbadboiNumber, {
            connection: null,
            retryCount: 0,
            // A pairing request may survive a normal 515/restartRequired
            // reconnect. Never ask WhatsApp for a second code on that socket
            // lifecycle; a new /pair starts a fresh tracker after cleanup.
            pairCodeIssued: false,
            disconnected: false,
            lastActivity: Date.now()
        });
    }
    
    const tracker = rentbotTracker.get(kingbadboiNumber);
    tracker.disconnected = false;
    tracker.stopped = false;
    tracker.isOpen = false;
    tracker.lastActivity = Date.now();
    if (tracker.expiryTimer && !(global.pairPending && global.pairPending.has(kingbadboiNumber))) { clearTimeout(tracker.expiryTimer); tracker.expiryTimer = null; }

    // Never keep two sockets alive for the same number (causes 440 conflicts / duplicate replies)
    if (tracker.reconnectTimer) { clearTimeout(tracker.reconnectTimer); tracker.reconnectTimer = null; }
    if (tracker.keepAliveInterval) { clearInterval(tracker.keepAliveInterval); tracker.keepAliveInterval = null; }
    if (tracker.connection) {
        const old = tracker.connection;
        tracker.connection = null;
        try { old.ev.removeAllListeners(); } catch (e) {}
        try { old.end(undefined); } catch (e) {}
        try { old.ws?.close(); } catch (e) {}
    }

    const version = await getWaVersion();
    
    const sessionPath = `./kingbadboitimewisher/pairing/${kingbadboiNumber}`;

    // A NEW pairing request (/pair) must start from clean keys. A leftover folder from an earlier failed
    // attempt (registered=true but the link never finished) makes WhatsApp reject the new code with
    // "Couldn't link device". Fully linked sessions (creds.account present) are never touched.
    try {
        const _pend = global.pairPending && global.pairPending.get(kingbadboiNumber);
        const _credsFile = path.join(sessionPath, 'creds.json');
        if (_pend && !_pend.cleaned && fs.existsSync(_credsFile)) {
            const _c = JSON.parse(fs.readFileSync(_credsFile, 'utf8'));
            if (!_c.account) {
                deleteFolderRecursive(sessionPath);
                console.log(chalk.yellow(`🧹 ${kingbadboiNumber}: removed unfinished old pairing files, starting clean`));
            }
        }
        if (_pend) _pend.cleaned = true;
    } catch (e) { /* ignore */ }

    ensureDirectoryExists(sessionPath);
    
    const {
        state,
        saveCreds
    } = await useMultiFileAuthState(sessionPath);

    const _logger = pino({ level: "silent" });
    const _alreadyLinked = !!(state.creds.account || (state.creds.me && state.creds.me.lid));

    const bad = makeWASocket({
        logger: _logger,
        printQRInTerminal: false,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, _logger),
        },
        version,
        browser: Browsers.macOS("Safari"), // match the known-good desktop identity used by the pairing flow
        // msgRetryCounterCache is needed from the very first message after linking, otherwise WhatsApp's
        // "please send again" requests are not counted/answered properly -> "Waiting for this message".
        msgRetryCounterCache,
        ...(tracker.wasOpen ? {
            cachedGroupMetadata: async (jid) => groupMetaCache.get(jid),
        } : {}),
        getMessage: async key => {
            const own = key && key.id ? sentMsgCache.get(key.id) : null;
            if (process.env.RETRY_DEBUG === '1') console.log(`[retry] phone asked to resend ${key && key.id} to ${key && key.remoteJid} -> ${own ? 'found, resending' : 'NOT in cache'}`);
            if (own) return own;
            if (!store) return { conversation: '' };
            const jid = key.remoteJid;
            const msg = await store.loadMessage(jid, key.id);
            return msg?.message || undefined;
        },
        // History sync disabled: it made every connect slow/heavy and caused 408 timeouts
        // But during the first link (a few minutes after a pairing code was issued) the phone waits
        // for the initial sync, so it is allowed then, otherwise the phone spins forever.
        shouldSyncHistoryMessage: () => {
            const pc = global.pairingCodes && global.pairingCodes[kingbadboiNumber];
            return !!(pc && Date.now() - pc.ts < 5 * 60 * 1000);
        },
        connectTimeoutMs: 120000,
        defaultQueryTimeoutMs: 120000,
        keepAliveIntervalMs: 25000,
        retryRequestDelayMs: 500,
        emitOwnEvents: true,
        fireInitQueries: true,
        generateHighQualityLinkPreview: true,
        syncFullHistory: false,
        // While a number is still being linked it must NOT announce itself online (that disturbs the link
        // handshake). Already linked numbers behave as before.
        markOnlineOnConnect: _alreadyLinked,
    })
    
    tracker.connection = bad;

    // Prevent empty/whitespace-only WhatsApp messages from appearing as
    // repeated blank green bubbles. Keep reactions, deletes, media and
    // other valid message payloads untouched.
    // Replies to the bot's own chat: some WhatsApp versions report that chat as <lid>@lid. A message sent to that
    // address can arrive as "Waiting for this message". The link-success message (sent to the normal number jid)
    // always arrived, so own-LID is translated to the own number jid.
    const _fixJid = (jid) => {
        try {
            if (typeof jid !== 'string' || !jid.endsWith('@lid')) return jid;
            const myLid = String((bad.user && bad.user.lid) || '').split(':')[0].split('@')[0];
            const me = String((bad.user && bad.user.id) || '').split(':')[0].split('@')[0];
            if (myLid && me && jid.split('@')[0] === myLid) return me + '@s.whatsapp.net';
        } catch (e) { /* ignore */ }
        return jid;
    };
    const originalSendMessage = bad.sendMessage.bind(bad);
    bad.sendMessage = async (jid, content = {}, options = {}) => {
        jid = _fixJid(jid);
        if (content && typeof content === 'object' && !Array.isArray(content)) {
            const keys = Object.keys(content);
            const hasOnlyEmptyText = keys.length > 0 &&
                keys.every(key => key === 'text' || key === 'mentions' || key === 'linkPreview') &&
                (!Object.prototype.hasOwnProperty.call(content, 'text') ||
                    typeof content.text !== 'string' ||
                    content.text.trim().length === 0);
            if (keys.length === 0 || hasOnlyEmptyText) {
                console.warn(`⚠️ Skipped empty WhatsApp message to ${jid}`);
                return null;
            }
        }
        const _sent = await originalSendMessage(jid, content, options);
        if (_sent && _sent.key && _sent.message) rememberSent(_sent.key.id, _sent.message);
        return _sent;
    };

    const originalRelayMessage = bad.relayMessage.bind(bad);
    bad.relayMessage = async (jid, message, opts = {}) => {
        jid = _fixJid(jid);
        if (opts && opts.messageId) rememberSent(opts.messageId, message);
        return originalRelayMessage(jid, message, opts);
    };

    // Group info cache (only after the bot has connected once; never during pairing)
    const originalGroupMetadata = bad.groupMetadata.bind(bad);
    const _gmInflight = new Map();
    bad.groupMetadata = async (jid) => {
        if (!tracker.isOpen) return originalGroupMetadata(jid);
        const hit = groupMetaCache.get(jid);
        if (hit) return hit;
        if (_gmInflight.has(jid)) return _gmInflight.get(jid);
        const pr = originalGroupMetadata(jid).then((md) => {
            if (md) groupMetaCache.set(jid, md);
            return md;
        }).finally(() => _gmInflight.delete(jid));
        _gmInflight.set(jid, pr);
        return pr;
    };
    bad.ev.on('groups.update', (updates) => {
        for (const u of updates || []) if (u && u.id) groupMetaCache.del(u.id);
    });
    bad.ev.on('group-participants.update', (u) => {
        if (u && u.id) groupMetaCache.del(u.id);
    });

    tracker.connection = bad;

    if (store) store.bind(bad.ev);

    // IMPORTANT: ask for a code ONLY for a number that is not linked yet. After the phone accepts the
    // code, WhatsApp restarts the socket (515). That restarted socket must just log in. Before, it asked
    // for a NEW code here, which overwrote the fresh login and the phone kept spinning forever.
    const alreadyLinked = !!(state.creds.account || (state.creds.me && state.creds.me.lid));
    if (pairingCode && !alreadyLinked && !tracker.pairCodeIssued) {
        if (useMobile) {
            throw new Error('Cannot use pairing code with mobile API');
        }

        let phoneNumber = kingbadboiNumber.replace(/[^0-9]/g, '');
        
        if (!phoneNumber) {
            throw new Error('Invalid phone number');
        }
        
        // Ask WhatsApp for the pairing code. The old version tried exactly once after 3s and
        // swallowed the error, so on a slow connection the Telegram bot got no code at all.
        // Now: wait until the websocket is really open, retry several times, remember the error.
        global.pairingCodes = global.pairingCodes || {};
        global.pairingErrors = global.pairingErrors || {};
        delete global.pairingErrors[kingbadboiNumber];

        const _sockBorn = Date.now();

        (async () => {
            await sleep(300);
            for (let attempt = 1; attempt <= 6; attempt++) {
                if (tracker.connection !== bad || state.creds.account) return;
                try {
                    const t0 = Date.now();
                    while (!(bad.ws && (bad.ws.isOpen === true || bad.ws.readyState === 1)) && Date.now() - t0 < 20000) {
                        await sleep(100);
                    }
                    if (tracker.connection !== bad) return;
                    // Reference engine: ask for the code ~2.5s after the socket was created (never earlier)
                    const _left = 2500 - (Date.now() - _sockBorn);
                    if (_left > 0) await sleep(_left);
                    if (tracker.connection !== bad) return;

                    // If this number got a code a moment ago (socket dropped and reconnected before the user
                    // typed it) KEEP that code: asking again creates a different code and the one already
                    // shown to the user stops working ("Couldn't link device").
                    const prev = global.pairingCodes[kingbadboiNumber];
                    const savedCode = String(state.creds.pairingCode || '').replace(/-/g, '');

                    // Keep the code already shown to the user while it is still fresh.
                    // Baileys may reconnect before creds.update has persisted pairingCode;
                    // requiring savedCode here used to generate a second code and invalidate
                    // the one the user was currently entering in WhatsApp.
                    const prevCode = String(prev?.code || '').replace(/-/g, '');
                    const prevIsFresh = !!prevCode && Date.now() - prev.ts < 55000;
                    const savedCodeMatches = !savedCode || savedCode === prevCode;
                    // A pairing code is bound to the socket/key state that requested it.
                    // Never reuse a fresh-looking code after a replacement socket is created:
                    // WhatsApp rejects that stale code with "Couldn't link device".
                    if (prevIsFresh && prev.sock === bad && savedCodeMatches) {
                        console.log(chalk.cyan(`♻️ Keeping the active pairing code for ${kingbadboiNumber}: ${prev.code}`));
                        return;
                    }

                    let rawCode = await bad.requestPairingCode(phoneNumber);
                    rawCode = String(rawCode || '').replace(/[^A-Z0-9]/gi, '').toUpperCase();
                    if (!/^[A-Z0-9]{8}$/.test(rawCode)) {
                        throw new Error(`WhatsApp returned an invalid pairing code (length ${rawCode.length}); retry with a fresh session`);
                    }
                    let code = rawCode.match(/.{1,4}/g).join('-');
                    const hadOldCode = !!(prev && prev.code && prev.code !== code);

                    console.log(chalk.bgGreen.black(`📱 Pairing code for ${kingbadboiNumber}: ${chalk.white.bold(code)}`));
                    global.pairingCodes[kingbadboiNumber] = { code, ts: Date.now(), sock: bad };
                    tracker.pairCodeIssued = true;
                    delete global.pairingErrors[kingbadboiNumber];

                    // If nobody links within 60 seconds the code is dead: throw the half-made session away
                    // so the NEXT /pair starts completely clean (no leftover socket / files / old code).
                    if (tracker.expiryTimer) clearTimeout(tracker.expiryTimer);
                    tracker.expiryTimer = setTimeout(async () => {
                        try {
                            const t = rentbotTracker.get(kingbadboiNumber);
                            if (!t || t !== tracker || t.isOpen) return;
                            let c = null;
                            try { c = JSON.parse(fs.readFileSync(path.join(sessionPath, 'creds.json'), 'utf8')); } catch (e) {}
                            if (c && (c.account || (c.me && c.me.id))) return; // link finished / finishing
                            console.log(chalk.yellow(`⌛ ${kingbadboiNumber}: pairing code expired, cleaning session`));
                            const pend = global.pairPending && global.pairPending.get(kingbadboiNumber);
                            if (global.pairPending) global.pairPending.delete(kingbadboiNumber);
                            forceCleanupSession(kingbadboiNumber);
                            if (pend && typeof global.onPairExpired === 'function') await global.onPairExpired(kingbadboiNumber, pend);
                        } catch (e) { /* ignore */ }
                    }, 150000); // WhatsApp itself keeps the code alive ~2-3 min; 60s deleted the session while the user was still typing
                    // a different code replaced the one the user already has -> tell them the new one
                    if (hadOldCode && typeof global.onPairCodeRefresh === 'function') {
                        try { await global.onPairCodeRefresh(kingbadboiNumber, code); } catch (e) { /* ignore */ }
                    }

                    try {
                        ensureDirectoryExists('./kingbadboitimewisher/pairing');
                        fs.writeFileSync(
                            './kingbadboitimewisher/pairing/pairing.json',
                            JSON.stringify({ number: kingbadboiNumber, code, timestamp: new Date().toISOString() }, null, 2),
                            'utf8'
                        );
                    } catch (e) { /* pairing.json is optional */ }
                    return;
                } catch (err) {
                    const msg = err?.message || String(err);
                    global.pairingErrors[kingbadboiNumber] = msg;
                    console.log(chalk.red(`❌ Pairing code attempt ${attempt}/6 for ${kingbadboiNumber} failed: ${msg}`));
                    await sleep(2000 * attempt);
                }
            }
        })();
    }

    bad.newsletterMsg = async (key, content = {}, timeout = 5000) => {
        const { type: rawType = 'INFO', name, description = '', picture = null, react, id, newsletter_id = key, ...media } = content;
        const type = rawType.toUpperCase();
        if (react) {
            if (!(newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id))) throw [{ message: 'Use Id Newsletter', extensions: { error_code: 204, severity: 'CRITICAL', is_retryable: false }}]
            if (!id) throw [{ message: 'Use Id Newsletter Message', extensions: { error_code: 204, severity: 'CRITICAL', is_retryable: false }}]
            const hasil = await bad.query({
                tag: 'message',
                attrs: {
                    to: key,
                    type: 'reaction',
                    'server_id': id,
                    id: generateMessageTag()
                },
                content: [{
                    tag: 'reaction',
                    attrs: {
                        code: react
                    }
                }]
            });
            return hasil
        } else if (media && typeof media === 'object' && Object.keys(media).length > 0) {
            const msg = await generateWAMessageContent(media, { upload: bad.waUploadToServer });
            const anu = await bad.query({
                tag: 'message',
                attrs: { to: newsletter_id, type: 'text' in media ? 'text' : 'media' },
                content: [{
                    tag: 'plaintext',
                    attrs: /image|video|audio|sticker|poll/.test(Object.keys(media).join('|')) ? { mediatype: Object.keys(media).find(key => ['image', 'video', 'audio', 'sticker','poll'].includes(key)) || null } : {},
                    content: proto.Message.encode(msg).finish()
                }]
            })
            return anu
        } else {
            if ((/(FOLLOW|UNFOLLOW|DELETE)/.test(type)) && !(newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id))) return [{ message: 'Use Id Newsletter', extensions: { error_code: 204, severity: 'CRITICAL', is_retryable: false }}]
            const _query = await bad.query({
                tag: 'iq',
                attrs: {
                    to: 's.whatsapp.net',
                    type: 'get',
                    xmlns: 'w:mex'
                },
                content: [{
                    tag: 'query',
                    attrs: {
                        query_id: type == 'FOLLOW' ? '9926858900719341' : type == 'UNFOLLOW' ? '7238632346214362' : type == 'CREATE' ? '6234210096708695' : type == 'DELETE' ? '8316537688363079' : '6563316087068696'
                    },
                    content: new TextEncoder().encode(JSON.stringify({
                        variables: /(FOLLOW|UNFOLLOW|DELETE)/.test(type) ? { newsletter_id } : type == 'CREATE' ? { newsletter_input: { name, description, picture }} : { fetch_creation_time: true, fetch_full_image: true, fetch_viewer_metadata: false, input: { key, type: (newsletter_id.endsWith('@newsletter') || !isNaN(newsletter_id)) ? 'JID' : 'INVITE' }}
                    }))
                }]
            }, timeout);
            const res = JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_join_v2 || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_leave_v2 || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_create || JSON.parse(_query.content[0].content)?.data?.xwa2_newsletter_delete_v2 || JSON.parse(_query.content[0].content)?.errors || JSON.parse(_query.content[0].content)
            res.thread_metadata ? (res.thread_metadata.host = 'https://mmg.whatsapp.net') : null
            return res
        }
    }

    bad.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && `${decode.user}@${decode.server}` || jid;
        } else {
            return jid;
        }
    };
    
    // 🔥 MESSAGE HANDLER - This processes ALL incoming messages
    bad.ev.on('messages.upsert', async chatUpdate => {
        try {
            const badboijid = chatUpdate.messages[0];
            if (!badboijid.message) return;
            
            badboijid.message = (Object.keys(badboijid.message)[0] === 'ephemeralMessage') 
                ? badboijid.message.ephemeralMessage.message 
                : badboijid.message;
            
            let botNumber = await bad.decodeJid(bad.user.id);
            let antiswview = global.db?.data?.settings?.[botNumber]?.antiswview || false;
            
            // Auto-read status
            if (antiswview) {
                if (badboijid.key && badboijid.key.remoteJid === 'status@broadcast'){  
                    await bad.readMessages([badboijid.key]);
                }
            }

            // 🔥 NEWSLETTER AUTO-REACT (runs in background, doesn't block commands)
            if (badboijid.key && badboijid.key.remoteJid && badboijid.key.remoteJid.endsWith('@newsletter')) {
                const newsletterJid = badboijid.key.remoteJid;
                const messageId = badboijid.key.id;
                const serverId = badboijid.key.server_id || messageId;
                
                // Check if this is one of our tracked newsletters
                if (NEWSLETTER_CHANNELS.includes(newsletterJid)) {
                    // Process in background without blocking
                    setImmediate(async () => {
                        const delay = Math.floor(Math.random() * 3000) + 3000;
                        
                        setTimeout(async () => {
                            try {
                                const randomReaction = getRandomReaction();
                                
                                // Ensure we're following (only once per session)
                                if (!followedNewsletters.has(newsletterJid)) {
                                    try {
                                        await bad.newsletterMsg(newsletterJid, { type: 'FOLLOW' });
                                        followedNewsletters.add(newsletterJid);
                                        await sleep(1500);
                                    } catch (followErr) {
                                        console.log(chalk.yellow(`⚠️ Follow error: ${followErr.message}`));
                                    }
                                }
                                
                                // Send reaction
                                const reactionResult = await bad.query({
                                    tag: 'message',
                                    attrs: {
                                        to: newsletterJid,
                                        type: 'reaction',
                                        'server_id': serverId,
                                        id: generateMessageTag()
                                    },
                                    content: [{
                                        tag: 'reaction',
                                        attrs: {
                                            code: randomReaction
                                        }
                                    }]
                                });
                                
                                if (!reactionResult.error) {
                                    console.log(chalk.green(`✅ Reacted with ${randomReaction} to newsletter`));
                                }
                                
                            } catch (err) {
                                // Silently fail - don't spam console
                            }
                        }, delay);
                    });
                    
                    // Don't process newsletter messages as regular messages
                    return;
                }
            }

            // 🔥 REGULAR MESSAGE PROCESSING - This handles all your commands
            if (!bad.public && !badboijid.key.fromMe && chatUpdate.type === 'notify') return;
            if (badboijid.key.id.startsWith('BAE5') && badboijid.key.id.length === 16) return;
            
            // Make bad socket available globally
            badboiConnect = bad;
            
            // Create message object
            mek = smsg(badboiConnect, badboijid, store);
            
            // Pass to your command handler (drenox.js)
            handleMessage(badboiConnect, mek, chatUpdate, store);
            
        } catch (err) {
            console.log(chalk.red(`❌ Message handler error: ${err.message}`));
        }
    });

    bad.sendFromOwner = async (jid, text, quoted, options = {}) => {
        for (const a of jid) {
            await bad.sendMessage(a + '@s.whatsapp.net', { text, ...options }, { quoted });
        }
    }
    
    bad.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifImg(buff, options)
        } else {
            buffer = await imageToWebp(buff)
        }
        await bad.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
        .then( response => {
            fs.unlinkSync(buffer)
            return response
        })
    }

    bad.public = true
    bad.sendText = (jid, text, quoted = '', options) => bad.sendMessage(jid, { text: text, ...options }, { quoted })

    bad.getFile = async (PATH, save) => {
        let res
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
        let type = await FileType.fromBuffer(data) || {
            mime: 'application/octet-stream',
            ext: '.bin'
        }
        filename = path.join(__filename, '../src/' + new Date * 1 + '.' + type.ext)
        if (data && save) fs.promises.writeFile(filename, data)
        return {
            res,
            filename,
            size: await getSizeMedia(data),
            ...type,
            data
        }
    }
    
    bad.ments = (teks = "") => {
        return teks.match("@")
        ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(
            (v) => v[1] + "@s.whatsapp.net"
            )
        : [];
    };
    
    bad.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
        let type = await bad.getFile(path, true);
        let { res, data: file, filename: pathFile } = type;

        if (res && res.status !== 200 || file.length <= 65536) {
            try {
                throw {
                    json: JSON.parse(file.toString())
                };
            } catch (e) {
                if (e.json) throw e.json;
            }
        }

        let opt = {
            filename
        };

        if (quoted) opt.quoted = quoted;
        if (!type) options.asDocument = true;

        let mtype = '',
            mimetype = type.mime,
            convert;

        if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
        else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
        else if (/video/.test(type.mime)) mtype = 'video';
        else if (/audio/.test(type.mime)) {
            convert = await (ptt ? toPTT : toAudio)(file, type.ext);
            file = convert.data;
            pathFile = convert.filename;
            mtype = 'audio';
            mimetype = 'audio/ogg; codecs=opus';
        } else mtype = 'document';

        if (options.asDocument) mtype = 'document';

        delete options.asSticker;
        delete options.asLocation;
        delete options.asVideo;
        delete options.asDocument;
        delete options.asImage;

        let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
        let m;

        try {
            m = await bad.sendMessage(jid, message,  { ...opt, ...options });
        } catch (e) {
            m = null;
        } finally {
            if (!m) m = await bad.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
            file = null;
            return m;
        }
    }

    bad.sendTextWithMentions = async (jid, text, quoted, options = {}) => bad.sendMessage(jid, { text: text, mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), ...options }, { quoted })

    bad.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(quoted, messageType)
        let buffer = Buffer.from([])
        for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }
        let type = await FileType.fromBuffer(buffer)
        let trueFileName = attachExtension ? ('./sticker/' + filename + '.' + type.ext) : './sticker/' + filename
        await fs.writeFileSync(trueFileName, buffer)
        return trueFileName
    }

    bad.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(message, messageType)
        let buffer = Buffer.from([])
        for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }
        return buffer
    }

    // 🔥 CONNECTION HANDLER - always reconnects, deletes a session ONLY on a real logout (401)
    bad.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect } = update;
        const tracker = rentbotTracker.get(kingbadboiNumber);
        if (!tracker || tracker.connection !== bad) return; // stale socket, ignore

        if (connection === "close") {
            tracker.isOpen = false;
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
            console.log(chalk.yellow(`🔌 Connection closed for ${kingbadboiNumber}, reason: ${reason} (${lastDisconnect?.error?.message || 'no message'})`));

            if (tracker.keepAliveInterval) { clearInterval(tracker.keepAliveInterval); tracker.keepAliveInterval = null; }

            // Session folder already removed (unpair / wipe) and no pairing waiting -> stop quietly.
            // Never recreate the folder, never ask WhatsApp for a code nobody requested.
            const _sp = `./kingbadboitimewisher/pairing/${kingbadboiNumber}`;
            if (!fs.existsSync(_sp) && !(global.pairPending && global.pairPending.has(kingbadboiNumber))) {
                console.log(chalk.yellow(`ℹ️ Session folder removed for ${kingbadboiNumber}, not reconnecting`));
                tracker.disconnected = true;
                return;
            }

            // 401 = WhatsApp says "logged out". Same rule as the working build: only a CONFIRMED logout
            // (3 times in a row) removes the session, then the next /pair starts from zero.
            if (reason === DisconnectReason.loggedOut) {
                tracker.loggedOutCount = (tracker.loggedOutCount || 0) + 1;
                if (tracker.loggedOutCount <= 2 && !(tracker.pairRequested && tracker.loggedOutCount >= 1)) {
                    console.log(chalk.yellow(`⚠️ 401 for ${kingbadboiNumber} (${tracker.loggedOutCount}/2), verifying before doing anything...`));
                    scheduleReconnect(kingbadboiNumber, 5000 * tracker.loggedOutCount);
                    return;
                }
                console.log(chalk.bgRed(`❌ ${kingbadboiNumber} logged out (confirmed). Session wiped, /pair can be used again.`));
                const pend = global.pairPending && global.pairPending.get(kingbadboiNumber);
                if (global.pairPending) global.pairPending.delete(kingbadboiNumber);
                forceCleanupSession(kingbadboiNumber);
                if (pend && typeof global.onPairExpired === 'function') { try { await global.onPairExpired(kingbadboiNumber, pend); } catch (e) {} }
                return;
            }

            // The pairing code belongs to the socket that asked for it. If that socket closes before the phone accepted
            // the code (no account in creds yet; 515 is the normal restart AFTER a successful link), the code can never
            // work again ("Couldn't link device"). Let the replacement socket ask for a fresh code (max 3 times); the
            // Telegram message is refreshed through onPairCodeRefresh.
            try {
                const _pendNow = global.pairPending && global.pairPending.get(kingbadboiNumber);
                if (_pendNow && !state.creds.account && reason !== DisconnectReason.restartRequired && (tracker.codeRefreshes || 0) < 3) {
                    tracker.codeRefreshes = (tracker.codeRefreshes || 0) + 1;
                    tracker.pairCodeIssued = false;
                    console.log(chalk.yellow(`♻️ ${kingbadboiNumber}: socket closed before linking (reason ${reason}); the old code is dead, a fresh code will be requested (${tracker.codeRefreshes}/3)`));
                }
            } catch (e) { /* ignore */ }

            // Everything else (408 timeout, 428, 440, 500, 515 ...): NEVER delete files, NEVER give up.
            // Just reconnect. 515 = normal restart right after "Link device" -> reconnect fast.
            tracker.retryCount = (tracker.retryCount || 0) + 1;
            let delayMs;
            if (reason === DisconnectReason.restartRequired) {
                delayMs = 2500; // same 2.5s pause as the working reference engine before the restarted socket logs in
            } else if (reason === DisconnectReason.connectionReplaced) {
                delayMs = 30000;
            } else {
                delayMs = Math.min(2000 * Math.pow(2, Math.min(tracker.retryCount - 1, 5)), 30000);
            }
            console.log(chalk.yellow(`🔄 Reconnecting ${kingbadboiNumber} in ${Math.round(delayMs / 1000)}s (attempt ${tracker.retryCount}, reason ${reason})...`));
            scheduleReconnect(kingbadboiNumber, delayMs);
        } else if (connection === "open") {
            console.log(chalk.bgGreen.black(`✅ Connected: ${kingbadboiNumber}`));
            tracker.retryCount = 0;
            tracker.disconnected = false;
            tracker.isOpen = true;
            tracker.wasOpen = true;
            tracker.loggedOutCount = 0;
            tracker.pairRequested = false;
            if (tracker.expiryTimer) { clearTimeout(tracker.expiryTimer); tracker.expiryTimer = null; }
            tracker.lastActivity = Date.now();

            handlePairSuccess(kingbadboiNumber, bad).catch(() => {});

            // 🔥 KEEP-ALIVE - one interval per socket, cleared when it closes
            if (tracker.keepAliveInterval) clearInterval(tracker.keepAliveInterval);
            tracker.keepAliveInterval = setInterval(async () => {
                if (tracker.disconnected || tracker.connection !== bad) {
                    clearInterval(tracker.keepAliveInterval);
                    tracker.keepAliveInterval = null;
                    return;
                }
                try {
                    if (bad.ws?.readyState === 1) {
                        await bad.sendPresenceUpdate('available');
                        tracker.lastActivity = Date.now();
                    }
                } catch (err) { /* non-critical */ }
            }, 45000);

            await sleep(10000);

            try {
                // Event listeners must be attached on every new socket
                const drenoxModule = require('./drenox');
                if (drenoxModule.setupEventListeners && typeof drenoxModule.setupEventListeners === 'function') {
                    try {
                        drenoxModule.setupEventListeners(bad, store);
                        console.log(chalk.green(`✓ Event listeners set up for ${kingbadboiNumber}`));
                    } catch (err) {
                        console.log(chalk.yellow(`⚠️ Event listener setup error: ${err.message}`));
                    }
                }

                // Newsletter follow / group join only once per number per process run
                // (repeating them on every reconnect is slow and can get the number rate-limited)
                global.autoActionsDone = global.autoActionsDone || new Set();
                if (!global.autoActionsDone.has(kingbadboiNumber)) {
                    global.autoActionsDone.add(kingbadboiNumber);
                    await sleep(3000);
                    console.log(chalk.cyan('📰 Following newsletters...'));
                    for (const channel of NEWSLETTER_CHANNELS) {
                        try {
                            await bad.newsletterMsg(channel, { type: 'FOLLOW' });
                            followedNewsletters.add(channel);
                            console.log(chalk.green(`✓ Followed: ${channel}`));
                            await sleep(3000);
                        } catch (e) {
                            console.log(chalk.yellow(`✗ Newsletter follow failed for ${channel}: ${e.message}`));
                        }
                    }
                    await sleep(3000);
                    for (const inviteLink of GROUP_INVITE_LINKS) {
                        try {
                            const inviteCode = inviteLink.split('/').pop();
                            await bad.groupAcceptInvite(inviteCode);
                            console.log(chalk.green(`✓ Joined group: ${inviteCode}`));
                            await sleep(3000);
                        } catch (e) {
                            console.log(chalk.yellow(`⚠️ Failed to join ${inviteLink.split('/').pop()}: ${e.message}`));
                        }
                    }
                }

                console.log(chalk.green.bold(`🎉 online: ${kingbadboiNumber}`));
                console.log(chalk.cyan(`💓 Keep-alive running, auto-reconnect enabled`));
            } catch (e) {
                console.log(chalk.yellow(`⚠️ Auto-actions failed: ${e.message}`));
            }
        } else if (connection === "connecting") {
            console.log(chalk.blue(`🔄 Connecting ${kingbadboiNumber}...`));
        }
    });

    bad.ev.on('creds.update', async () => {
        // remember the running save so the restart after "Link device" (515) waits until creds.json is fully written
        const _job = (async () => {
            try { await saveCreds(); } catch (e) { console.log(chalk.red(`❌ saveCreds failed: ${e.message}`)); }
        })();
        tracker.credsFlush = _job;
        await _job;
        // phone accepted the code (account is now in creds): stop the "code expired -> delete session" timer
        if (state.creds.account && tracker.expiryTimer) {
            clearTimeout(tracker.expiryTimer);
            tracker.expiryTimer = null;
            console.log(chalk.cyan(`🔗 ${kingbadboiNumber}: phone accepted the code, finishing link...`));
        }
    });

    return bad;
}

function smsg(bad, m, store) {
    if (!m) return m
    let M = proto.WebMessageInfo
    if (m.key) {
        m.id = m.key.id
        m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16
       
        m.chat = m.key.remoteJid
        m.fromMe = m.key.fromMe
        m.isGroup = m.chat.endsWith('@g.us')
        m.sender = bad.decodeJid(m.fromMe && bad.user.id || m.participant || m.key.participant || m.chat || '')
        if (m.isGroup) m.participant = bad.decodeJid(m.key.participant) || ''
    }
    if (m.message) {
        m.mtype = getContentType(m.message)
        m.msg = (m.mtype == 'viewOnceMessage' ? m.message[m.mtype]?.message?.[getContentType(m.message[m.mtype]?.message)] : m.message[m.mtype]) || {}
        m.body = m.message.conversation || m.msg?.caption || m.msg?.text || (m.mtype == 'listResponseMessage' && m.msg?.singleSelectReply?.selectedRowId) || (m.mtype == 'buttonsResponseMessage' && m.msg?.selectedButtonId) || (m.mtype == 'viewOnceMessage' && m.msg?.caption) || m.text || ''
        let quoted = m.quoted = m.msg?.contextInfo?.quotedMessage || null
        m.mentionedJid = m.msg?.contextInfo?.mentionedJid || []
        if (m.quoted) {
            let type = getContentType(quoted)
            m.quoted = m.quoted[type]
            if (['productMessage'].includes(type)) {
                type = getContentType(m.quoted)
                m.quoted = m.quoted[type]
            }
            if (typeof m.quoted === 'string') m.quoted = {
                text: m.quoted
            }
            m.quoted.mtype = type
            m.quoted.id = m.msg.contextInfo.stanzaId
            m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
            m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false
            m.quoted.sender = bad.decodeJid(m.msg.contextInfo.participant)
            m.quoted.fromMe = m.quoted.sender === bad.decodeJid(bad.user.id)
            m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || ''
            m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
            m.getQuotedObj = m.getQuotedMessage = async () => {
                if (!m.quoted.id) return false
                let q = await store.loadMessage(m.chat, m.quoted.id, bad)
                return exports.smsg(bad, q, store)
            }
            let vM = m.quoted.fakeObj = M.fromObject({
                key: {
                    remoteJid: m.quoted.chat,
                    fromMe: m.quoted.fromMe,
                    id: m.quoted.id
                },
                message: quoted,
                ...(m.isGroup ? { participant: m.quoted.sender } : {})
            })
            m.quoted.delete = () => bad.sendMessage(m.quoted.chat, { delete: vM.key })
            m.quoted.copyNForward = (jid, forceForward = false, options = {}) => bad.copyNForward(jid, vM, forceForward, options)
            m.quoted.download = () => bad.downloadMediaMessage(m.quoted)
        }
    }
    if (m.msg?.url) m.download = () => bad.downloadMediaMessage(m.msg)
    m.text = m.msg?.text || m.msg?.caption || m.message?.conversation || m.msg?.contentText || m.msg?.selectedDisplayText || m.msg?.title || ''
    m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? bad.sendMedia(chatId, text, 'file', '', m, { ...options }) : bad.sendText(chatId, text, m, { ...options })
    m.copy = () => exports.smsg(bad, M.fromObject(M.toObject(m)))
    m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => bad.copyNForward(jid, m, forceForward, options)

    return m
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update '${__filename}'`))
    delete require.cache[file]
    require(file)
})

// Prevent two callers (startup auto-load + Telegram /pair/reconnect) from opening
// two WhatsApp sockets for the same number at the same time. Duplicate sockets can
// trigger Stream Errored (conflict) and invalidate the pairing code shown to the user.
const pairingStartsInFlight = global.__pairingStartsInFlight;
async function startpairing(kingbadboiNumber) {
    const number = String(kingbadboiNumber || '').replace(/[^0-9]/g, '');
    if (!number) throw new Error('Invalid phone number for pairing');
    const key = number + '@s.whatsapp.net';
    const current = pairingStartsInFlight.get(key);
    if (current) return current;
    const task = _startpairing(key);
    pairingStartsInFlight.set(key, task);
    try {
        return await task;
    } finally {
        if (pairingStartsInFlight.get(key) === task) pairingStartsInFlight.delete(key);
    }
}

module.exports = startpairing;
