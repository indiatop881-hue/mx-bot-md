// Runs before the bot starts. Downloads yt-dlp binary if missing. NEVER fails the start.
const fs = require("fs"), path = require("path"), https = require("https");
const dir = path.join(__dirname, "..", "node_modules", "youtube-dl-exec", "bin");
const file = path.join(dir, "yt-dlp");
function get(url, dest, n = 0) {
  return new Promise((res, rej) => {
    if (n > 6) return rej(new Error("too many redirects"));
    https.get(url, { headers: { "User-Agent": "vx-md-bot" } }, (r) => {
      if ([301, 302, 303, 307, 308].includes(r.statusCode) && r.headers.location)
        return res(get(r.headers.location, dest, n + 1));
      if (r.statusCode !== 200) return rej(new Error("HTTP " + r.statusCode));
      const w = fs.createWriteStream(dest);
      r.pipe(w); w.on("finish", () => w.close(res)); w.on("error", rej);
    }).on("error", rej);
  });
}
(async () => {
  try {
    if (!fs.existsSync(path.join(__dirname, "..", "node_modules", "youtube-dl-exec"))) return;
    if (fs.existsSync(file) && fs.statSync(file).size > 1e6) return;
    fs.mkdirSync(dir, { recursive: true });
    await get("https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux", file);
    fs.chmodSync(file, 0o755);
    console.log("[setup] yt-dlp ready");
  } catch (e) { console.log("[setup] yt-dlp skipped:", e.message); }
})().then(() => process.exit(0));
