// Keep Telegram credentials out of source control and ZIP files.
// Set BOT_TOKEN, TELEGRAM_GROUP_ID, and TELEGRAM_GROUP_LINK in Railway Variables.
module.exports = {
  BOT_TOKEN: String(process.env.BOT_TOKEN || '8919045231:AAEjFfY4KrG0AnIa5LmjH-kgRSn6XbeWMno').trim(),
  TELEGRAM_GROUP_ID: String(process.env.TELEGRAM_GROUP_ID || '-1004478827653').trim(),
  TELEGRAM_GROUP_LINK: String(process.env.TELEGRAM_GROUP_LINK || 'https://t.me/vxbot11').trim(),
};
